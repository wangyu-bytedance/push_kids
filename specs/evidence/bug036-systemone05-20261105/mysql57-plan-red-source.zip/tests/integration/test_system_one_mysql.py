"""Spec05 gates against explicitly configured disposable MySQL5.7 databases."""

import json
import os
from datetime import timedelta

import pytest
from alembic import command
from alembic.config import Config
from push_kids.agent_processing.history_search import recent_history_items
from push_kids.persistence.models import KnowledgeItem, Subject
from push_kids.platform.time import utcnow
from sqlalchemy import event, inspect, text

from tests.integration.test_supersession_mysql import app as mysql_app
from tests.integration.test_system_one_confirmation import (
    test_new_coverage_records_observed_before_supersession_and_skips_stale as confirmation_case,
)

pytestmark = pytest.mark.skipif(
    not os.getenv("PUSH_KIDS_TEST_MYSQL_URL"), reason="isolated MySQL5.7 not configured"
)


@pytest.fixture
def app(tmp_path, monkeypatch):
    yield from mysql_app.__wrapped__(tmp_path, monkeypatch)


def test_recent_history_mysql_large_inventory_and_actual_query_plan(app, child, family_headers):
    # MySQL5.7 migration DATETIME columns store whole seconds; use a persisted-time shape.
    family, cid = family_headers["X-Family-ID"], child["id"]
    as_of = utcnow().replace(microsecond=0)
    engine = app.state.database.engine
    with engine.connect() as connection:
        assert str(connection.scalar(text("SELECT VERSION()"))).startswith("5.7.")
    names = [f"合成学科{i:02}" for i in range(20)]
    expected = set()
    with app.state.database.session_factory() as db:
        for subject_index, name in enumerate(names):
            subject = Subject(family_id=family, child_id=cid, name=name, kind="learning")
            db.add(subject)
            db.flush()
            rows = []
            for index in range(2500):
                kid = f"{subject_index:02}{index:030}"
                rows.append(
                    {
                        "id": kid,
                        "family_id": family,
                        "child_id": cid,
                        "subject_id": subject.id,
                        "name": f"合成知识{index}",
                        "normalized_name": f"合成知识{index}",
                        "created_at": as_of + timedelta(days=1) if index == 2499 else as_of,
                        "review_status": "superseded" if index == 2498 else "normal",
                    }
                )
                if 2458 <= index <= 2497:
                    expected.add(kid)
            db.execute(KnowledgeItem.__table__.insert(), rows)
        db.commit()
        statements = []

        def capture(conn, cursor, statement, parameters, context, executemany):
            statements.append((statement, parameters))

        event.listen(engine, "before_cursor_execute", capture)
        try:
            result = recent_history_items(
                db, family_id=family, child_id=cid, subjects=names, as_of=as_of
            )
        finally:
            event.remove(engine, "before_cursor_execute", capture)
        assert len(result) == 800
        assert {item.knowledge_id for item in result} == expected
        assert len(statements) == 11
        for statement, parameters in statements[1:]:
            plan = (
                db.connection().exec_driver_sql("EXPLAIN " + statement, parameters).mappings().all()
            )
            branches = [row for row in plan if row["key"] == "ix_knowledge_recent_subject"]
            if len(branches) != 2:
                pytest.fail(json.dumps([dict(row) for row in plan], ensure_ascii=False))
            assert all(row["type"] in {"ref", "range"} for row in branches)
            assert all("Using filesort" not in (row["Extra"] or "") for row in branches)
        assert (
            recent_history_items(db, family_id="other", child_id=cid, subjects=names, as_of=as_of)
            == []
        )


@pytest.mark.parametrize("stale,same_day", [(False, False), (True, False), (False, True)])
def test_mysql_system_one_confirmation(app, child, family_headers, stale, same_day):
    confirmation_case(app, child, family_headers, stale, same_day)


def test_mysql_recent_index_upgrade_downgrade(app, monkeypatch):
    from pathlib import Path

    engine = app.state.database.engine
    url = engine.url.render_as_string(hide_password=False)
    monkeypatch.setenv("PUSH_KIDS_DATABASE_URL", url)
    config = Config()
    config.set_main_option(
        "script_location", str(Path(__file__).parents[2] / "apps/api/migrations")
    )
    config.set_main_option("sqlalchemy.url", url.replace("%", "%%"))
    command.downgrade(config, "20261105_0026")
    assert "ix_knowledge_recent_subject" not in {
        item["name"] for item in inspect(engine).get_indexes("knowledge_items")
    }
    command.upgrade(config, "20261105_0027")
    indexes = {
        item["name"]: item["column_names"]
        for item in inspect(engine).get_indexes("knowledge_items")
    }
    assert indexes["ix_knowledge_recent_subject"] == [
        "family_id",
        "child_id",
        "subject_id",
        "review_status",
        "created_at",
        "id",
    ]
