"""Validated System One answers and server-owned proposal decision snapshots."""

import math
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from push_kids.agent_processing.failures import StageFailure
from push_kids.agent_processing.stage_contracts import QualityReviewResult

DECISION_REVISION = "system-one-20261105-01"


class DecisionAnswer(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    type: Literal["noul", "choice"]
    noul: float | None = Field(default=None, ge=0, le=1, allow_inf_nan=False)
    choice: str | None = None
    confidence: float | None = Field(default=None, ge=0, le=1, allow_inf_nan=False)
    probabilities: dict[str, float] | None = None

    @model_validator(mode="after")
    def validate_shape(self):
        if self.type == "noul":
            if self.noul is None or any(
                v is not None for v in (self.choice, self.confidence, self.probabilities)
            ):
                raise ValueError("invalid noul answer")
        else:
            values = self.probabilities or {}
            if (
                self.noul is not None
                or self.choice not in values
                or self.confidence is None
                or any(not math.isfinite(v) or not 0 <= v <= 1 for v in values.values())
                or abs(sum(values.values()) - 1) > 0.002
                or values[self.choice] < max(values.values()) - 0.000001
            ):
                raise ValueError("invalid choice answer")
        return self


class VerifiedRelation(BaseModel):
    model_config = ConfigDict(extra="forbid")
    candidate: str = Field(pattern=r"^i(?:[0-9]|1[0-9])$")
    history: str = Field(pattern=r"^h[0-9]{1,3}$")
    relation: Literal["equivalent", "covers"]


class DecisionReviewResult(QualityReviewResult):
    relations: list[VerifiedRelation] = Field(default_factory=list, max_length=400)
    uncertain_items: list[str] = Field(default_factory=list, max_length=20)


class LabelProbability(BaseModel):
    model_config = ConfigDict(extra="forbid")
    label: str
    probability: float = Field(ge=0, le=1, allow_inf_nan=False)


class FallbackDecision(BaseModel):
    model_config = ConfigDict(extra="forbid")
    question: str
    type: Literal["noul", "choice"]
    noul: float | None
    choice: str | None
    confidence: float | None
    probabilities: list[LabelProbability] = Field(max_length=33)


class FallbackAnswers(BaseModel):
    model_config = ConfigDict(extra="forbid")
    answers: list[FallbackDecision] = Field(max_length=24)

    def validated(self, questions: dict) -> dict[str, DecisionAnswer]:
        raw = {}
        for answer in self.answers:
            if answer.question in raw or len({p.label for p in answer.probabilities}) != len(
                answer.probabilities
            ):
                raise StageFailure("validation", retryable=False)
            raw[answer.question] = {
                "type": answer.type,
                "noul": answer.noul,
                "choice": answer.choice,
                "confidence": answer.confidence,
                "probabilities": {p.label: p.probability for p in answer.probabilities}
                if answer.probabilities
                else None,
            }
        try:
            return validate_answers(raw, questions)
        except ValueError:
            raise StageFailure("validation", retryable=False) from None


def validate_answers(raw: Any, questions: dict[str, dict[str, Any]]) -> dict[str, DecisionAnswer]:
    if not isinstance(raw, dict) or set(raw) != set(questions):
        raise ValueError("answer coverage")
    result = {}
    for key, question in questions.items():
        answer = DecisionAnswer.model_validate(raw[key])
        if answer.type != question["type"]:
            raise ValueError("answer type")
        if answer.type == "choice" and set(answer.probabilities or {}) != set(question["criteria"]):
            raise ValueError("choice coverage")
        result[key] = answer
    return result
