import asyncio
from time import monotonic

import pytest
from push_kids.agent_processing.contracts import AnalysisInput, ExistingKnowledgeContext
from push_kids.agent_processing.decision_contracts import DecisionAnswer
from push_kids.agent_processing.pipeline import StagedPipeline
from push_kids.agent_processing.telemetry import AnalysisTrace

from tests.staged_analysis_fakes import StageFake


class DecisionFake:
    model = "synthetic-decision"

    def __init__(self, relation="equivalent", reject_source=False):
        self.requests = []
        self.relation, self.reject_source = relation, reject_source

    async def evaluate(self, questions, state, images, deadline, trace):
        self.requests.append((questions, state))
        return {
            key: DecisionAnswer(
                type="noul", noul=0.1 if self.reject_source and key.endswith("_source") else 0.999
            )
            if question["type"] == "noul"
            else DecisionAnswer(
                type="choice",
                choice=self.relation,
                confidence=0.70,
                probabilities={
                    name: 0.999 if name == self.relation else 0.0002
                    for name in question["criteria"]
                },
            )
            for key, question in questions.items()
        }


def test_enabled_pipeline_uses_decisions_and_scoped_recent_history():
    provider = StageFake()
    provider.decision_provider = DecisionFake()
    data = AnalysisInput(text="十以内加法", existing_subjects=["数学"])
    history_calls = []

    def recent(subjects):
        history_calls.append(subjects)
        return [
            ExistingKnowledgeContext(
                knowledge_id="old",
                subject_name="数学",
                name="十以内加法",
                category="知识",
                review_method="用实物合并数量",
                evidence="根据两组数量求总数",
            )
        ]

    result = asyncio.run(
        StagedPipeline(provider, AnalysisTrace.disabled()).run(
            data,
            lambda request: [],
            monotonic() + 5,
            recent_search=recent,
        )
    )
    assert history_calls and provider.decision_provider.requests
    assert not any(stage in {"review", "match", "reuse", "coverage"} for stage, _ in provider.calls)
    assert result.todo_matches[0].knowledge_id == "old"


def test_uncertain_match_cannot_be_reused_from_checkpoint():
    from push_kids.agent_processing.stage_contracts import MatchDecision, MatchingResult

    assert not StagedPipeline._checkpoint_reusable(
        "match",
        MatchingResult(decisions=[MatchDecision(candidate="i0", match=None, uncertain=True)]),
    )


def test_same_name_partial_relation_cannot_silently_reuse_confirmation_identity():
    from push_kids.agent_processing.failures import StageFailure

    provider = StageFake()
    provider.decision_provider = DecisionFake(relation="partial")
    data = AnalysisInput(
        text="十以内加法",
        existing_subjects=["数学"],
        existing_knowledge=[
            ExistingKnowledgeContext(
                knowledge_id="old",
                subject_name="数学",
                name="十以内加法",
                category="知识",
                review_method="不同技能",
                evidence="合成的不同技能",
            ),
        ],
    )
    with pytest.raises(StageFailure) as failure:
        asyncio.run(
            StagedPipeline(provider, AnalysisTrace.disabled()).run(
                data, lambda request: [], monotonic() + 5
            )
        )
    assert failure.value.stage == "match" and failure.value.reason == "quality"
    assert not failure.value.retryable


def test_failed_source_check_has_one_correction_then_terminal_refusal():
    from push_kids.agent_processing.failures import StageFailure

    provider = StageFake()
    provider.decision_provider = DecisionFake(reject_source=True)
    data = AnalysisInput(text="十以内加法", existing_subjects=["数学"])
    with pytest.raises(StageFailure) as failure:
        asyncio.run(
            StagedPipeline(provider, AnalysisTrace.disabled()).run(
                data, lambda request: [], monotonic() + 5
            )
        )
    assert failure.value.reason == "quality" and not failure.value.retryable
    assert provider.calls["merge", "merge"] == 2


def test_pro_fallback_cannot_hide_a_contradictory_answer_shape():
    from push_kids.agent_processing.decision_contracts import FallbackAnswers, FallbackDecision
    from push_kids.agent_processing.failures import StageFailure

    result = FallbackAnswers(
        answers=[
            FallbackDecision(
                question="q",
                type="noul",
                noul=0.99,
                choice="invented",
                confidence=0.99,
                probabilities=[],
            )
        ]
    )
    with pytest.raises(StageFailure):
        result.validated({"q": {"type": "noul"}})
