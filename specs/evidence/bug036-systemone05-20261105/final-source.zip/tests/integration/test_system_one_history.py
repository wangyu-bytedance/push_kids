from datetime import timedelta

from push_kids.agent_processing.history_search import recent_history_items
from push_kids.persistence.models import KnowledgeItem
from push_kids.platform.time import utcnow
from sqlalchemy import event, text

from tests.integration.test_review_inventory import seed


def test_maximum_system_one_path_keeps_eighteen_temporary_keys(
    client, app, child, family_headers, tmp_path
):
    import asyncio
    from time import monotonic

    from push_kids.agent_processing.contracts import AnalysisInput, ExistingKnowledgeContext
    from push_kids.agent_processing.decision_contracts import DecisionAnswer
    from push_kids.agent_processing.pipeline import StagedPipeline
    from push_kids.agent_processing.telemetry import AnalysisTrace

    from tests.integration.test_analysis_checkpoints import make_store
    from tests.staged_analysis_fakes import MaximumStages
    from tests.unit.test_system_one_workflow import DecisionFake

    class OneCorrection(DecisionFake):
        reviews = 0

        async def evaluate(self, questions, *args):
            result = await super().evaluate(questions, *args)
            if "summary" in questions:
                self.reviews += 1
                if self.reviews == 1:
                    result["i0_source"] = DecisionAnswer(type="noul", noul=0.1)
            return result

    store = make_store(client, app, family_headers, child)
    images = []
    for index in range(9):
        path = tmp_path / f"{index}.png"
        path.write_bytes(f"synthetic-{index}".encode())
        images.append(path)
    data = AnalysisInput(
        text="十以内加法",
        image_paths=images,
        existing_subjects=["数学"],
        existing_knowledge=[
            ExistingKnowledgeContext(
                knowledge_id="old",
                subject_name="数学",
                name="十以内加法",
                category="计算",
                evidence="合成来源",
            ),
        ],
    )
    provider = MaximumStages()
    provider.decision_provider = OneCorrection()
    proposal = asyncio.run(
        StagedPipeline(provider, AnalysisTrace.disabled(), store).run(
            data, lambda _: [], monotonic() + 10
        )
    )
    assert proposal.todo_matches[0].knowledge_id == "old"
    assert len(store.rows) == 18 and "classify" in store.rows and "reuse" not in store.rows


def test_recent_history_is_scoped_normal_asof_and_uses_bounded_index(app, child, family_headers):
    family, cid = family_headers["X-Family-ID"], child["id"]
    sid, ids = seed(app, family, cid, size=100)
    as_of = utcnow()
    with app.state.database.session_factory() as db:
        for index, (_, kid) in enumerate(ids):
            row = db.get(KnowledgeItem, kid)
            row.created_at = as_of - timedelta(minutes=index)
        db.get(KnowledgeItem, ids[0][1]).created_at = as_of + timedelta(days=1)
        db.get(KnowledgeItem, ids[1][1]).review_status = "superseded"
        db.commit()
        statements = []

        def capture(conn, cursor, statement, parameters, context, executemany):
            statements.append(statement)

        event.listen(db.bind, "before_cursor_execute", capture)
        try:
            rows = recent_history_items(
                db, family_id=family, child_id=cid, subjects=["测试数学"], as_of=as_of
            )
        finally:
            event.remove(db.bind, "before_cursor_execute", capture)
        assert [row.knowledge_id for row in rows] == [kid for _, kid in ids[2:42]]
        assert len(statements) == 2
        assert (
            recent_history_items(
                db, family_id="other", child_id=cid, subjects=["测试数学"], as_of=as_of
            )
            == []
        )
        plan = db.execute(
            text(
                "EXPLAIN QUERY PLAN SELECT id FROM knowledge_items "
                "WHERE family_id=:f AND child_id=:c AND subject_id=:s AND review_status='normal' "
                "AND created_at<=:d ORDER BY created_at DESC,id DESC LIMIT 40"
            ),
            {"f": family, "c": cid, "s": sid, "d": as_of},
        ).all()
        assert "ix_knowledge_recent_subject" in str(plan)
        assert "TEMP B-TREE" not in str(plan)
