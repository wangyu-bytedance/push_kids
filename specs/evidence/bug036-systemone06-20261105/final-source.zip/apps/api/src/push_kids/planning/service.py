from __future__ import annotations

import json
from dataclasses import dataclass, replace
from datetime import date, datetime, timedelta
from hashlib import sha256

from sqlalchemy import and_, case, delete, func, or_, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from push_kids.children.service import ChildrenService
from push_kids.persistence.models import (
    Child,
    DailyReviewPlan,
    DailyReviewPlanItem,
    KnowledgeItem,
    KnowledgeOccurrence,
    KnowledgeSearchTerm,
    LearningRecord,
    LearningSubmission,
    ReviewFeedback,
    ReviewFeedbackBatchRequest,
    ReviewFeedbackRequest,
    ReviewItem,
    ReviewQueueEntry,
    ReviewScheduleChange,
    ReviewScheduleOverride,
    Subject,
)
from push_kids.planning.completion_progress import (
    completion_cursor,
    prune_completion_receipts,
    purge_completion_data,
    record_completion,
)
from push_kids.planning.deletion import delete_knowledge
from push_kids.planning.domain import (
    DueKnowledge,
    group_daily_todos,
    review_interval_days,
)
from push_kids.planning.early_candidates import select_early_reviews
from push_kids.planning.early_review import EARLY_REVIEW_POLICY_REVISION
from push_kids.planning.eligibility import scheduling_eligible
from push_kids.planning.inventory import inventory_page, subjects_page
from push_kids.planning.plan_candidates import selected_candidates
from push_kids.planning.policies import (
    CURVE_HEAT_POLICY_REVISION,
    ReviewPolicyTransition,
    ReviewState,
    apply_review_event,
)
from push_kids.planning.queue_projection import projection_drift, rebuild_projection
from push_kids.planning.queue_state import initialize_queue, record_offered, reset_queue
from push_kids.planning.scheduling import consume_arrangement, schedule_review
from push_kids.planning.selection import (
    DAILY_REVIEW_CANDIDATE_LIMIT,
    DAILY_REVIEW_POLICY_REVISION,
    ReviewSelectionCandidate,
    select_daily_reviews,
)
from push_kids.platform.errors import ClientUpgradeRequiredError, ConflictError, NotFoundError
from push_kids.platform.pagination import decode_cursor, encode_cursor
from push_kids.platform.time import local_date, local_day_bounds, utcnow


def _source_evidence(payload: str | None) -> tuple[str | None, int | None]:
    """Read the first usable confirmed evidence without trusting historical JSON."""
    if not payload:
        return None, None
    try:
        entries = json.loads(payload)
    except (TypeError, ValueError):
        return None, None
    if not isinstance(entries, list):
        return None, None
    fallback: tuple[str | None, int | None] = (None, None)
    for entry in entries:
        if not isinstance(entry, dict) or entry.get("source") not in {"image", "parent_text"}:
            continue
        detail = entry.get("detail")
        if not isinstance(detail, str) or not detail.strip():
            continue
        image_index = entry.get("image_index")
        valid_image_index = (
            image_index
            if entry.get("source") == "image"
            and isinstance(image_index, int)
            and not isinstance(image_index, bool)
            and 1 <= image_index <= 9
            else None
        )
        if valid_image_index is not None:
            return detail.strip()[:200], valid_image_index
        if fallback[0] is None:
            fallback = (detail.strip()[:200], None)
    return fallback


def _confirmed_source_evidence(
    payload: str | None, source_id: str | None, name: str, proposal_json: str | None
) -> tuple[str | None, int | None]:
    """Resolve legacy evidence only when the original confirmed proposal proves its origin.

    Older confirmation could fill empty evidence from a later submission without changing the
    review's original submission id. A valid index alone cannot establish provenance.
    """
    summary, index = _source_evidence(payload)
    if not source_id:
        return (summary, None) if index is None else (None, None)
    if summary is None:
        return None, None
    try:
        proposal = json.loads(proposal_json or "null")
    except (TypeError, ValueError):
        return None, None
    points = proposal.get("knowledge_points") if isinstance(proposal, dict) else None
    if not isinstance(points, list):
        return None, None
    for point in points:
        if not isinstance(point, dict) or point.get("name") != name:
            continue
        evidence = point.get("direct_evidence")
        if not isinstance(evidence, list):
            continue
        if any(
            isinstance(entry, dict) and _source_evidence(json.dumps([entry])) == (summary, index)
            for entry in evidence
        ):
            return summary, index
    return None, None


@dataclass(frozen=True)
class PendingReviewLoad:
    """How much review one child still owes as of a local day.

    The count is the number of outstanding knowledge points, using exactly the same rule as the
    Today list: a review that has been given feedback is no longer due, so this stays a read of
    planning policy and never advances a schedule.
    """

    family_id: str
    child_id: str
    child_name: str
    pending_count: int
    subject_names: tuple[str, ...]


class PlanningService:
    scheduling_eligible = staticmethod(scheduling_eligible)
    completion_cursor = staticmethod(completion_cursor)
    prune_completion_receipts = staticmethod(prune_completion_receipts)
    initialize_queue = staticmethod(initialize_queue)
    review_queue_drift = staticmethod(projection_drift)
    rebuild_review_queue = staticmethod(rebuild_projection)
    delete_knowledge = staticmethod(delete_knowledge)
    inventory_page = staticmethod(inventory_page)
    inventory_subjects = staticmethod(subjects_page)
    schedule_review = staticmethod(schedule_review)

    @staticmethod
    def purge_data(db: Session, family_id: str, child_id: str | None) -> None:
        purge_completion_data(db, family_id, child_id)
        for model in (ReviewScheduleOverride, ReviewScheduleChange):
            scope = [model.family_id == family_id]
            if child_id is not None:
                scope.append(model.child_id == child_id)
            db.execute(delete(model).where(*scope))
        review_query = select(ReviewItem.id).where(ReviewItem.family_id == family_id)
        knowledge_query = select(KnowledgeItem.id).where(KnowledgeItem.family_id == family_id)
        if child_id is not None:
            review_query = review_query.where(ReviewItem.child_id == child_id)
            knowledge_query = knowledge_query.where(KnowledgeItem.child_id == child_id)
        review_ids = list(db.scalars(review_query))
        knowledge_ids = list(db.scalars(knowledge_query))
        record_query = select(LearningRecord.id).where(LearningRecord.family_id == family_id)
        if child_id is not None:
            record_query = record_query.where(LearningRecord.child_id == child_id)
        record_ids = list(db.scalars(record_query))
        batch_query = delete(ReviewFeedbackBatchRequest).where(
            ReviewFeedbackBatchRequest.family_id == family_id
        )
        if child_id is not None:
            batch_query = batch_query.where(ReviewFeedbackBatchRequest.child_id == child_id)
        db.execute(batch_query)
        plan_query = select(DailyReviewPlan.id).where(DailyReviewPlan.family_id == family_id)
        if child_id is not None:
            plan_query = plan_query.where(DailyReviewPlan.child_id == child_id)
        plan_ids = list(db.scalars(plan_query))
        db.execute(
            delete(DailyReviewPlanItem).where(
                DailyReviewPlanItem.family_id == family_id,
                DailyReviewPlanItem.plan_id.in_(plan_ids),
            )
        )
        db.execute(delete(DailyReviewPlan).where(DailyReviewPlan.id.in_(plan_ids)))
        db.execute(
            delete(ReviewFeedbackRequest).where(
                ReviewFeedbackRequest.family_id == family_id,
                ReviewFeedbackRequest.review_item_id.in_(review_ids),
            )
        )
        db.execute(
            delete(ReviewFeedback).where(
                ReviewFeedback.family_id == family_id,
                ReviewFeedback.review_item_id.in_(review_ids),
            )
        )
        db.execute(
            delete(KnowledgeOccurrence).where(
                KnowledgeOccurrence.family_id == family_id,
                or_(
                    KnowledgeOccurrence.knowledge_item_id.in_(knowledge_ids),
                    KnowledgeOccurrence.learning_record_id.in_(record_ids),
                ),
            )
        )
        db.execute(
            delete(KnowledgeSearchTerm).where(
                KnowledgeSearchTerm.family_id == family_id,
                KnowledgeSearchTerm.knowledge_item_id.in_(knowledge_ids),
            )
        )
        # Set-based deletion avoids one cascading projection delete per historical review.
        db.execute(
            delete(ReviewQueueEntry).where(
                ReviewQueueEntry.family_id == family_id,
                ReviewQueueEntry.review_item_id.in_(review_ids),
            )
        )
        db.execute(delete(ReviewItem).where(ReviewItem.id.in_(review_ids)))
        db.execute(delete(KnowledgeItem).where(KnowledgeItem.id.in_(knowledge_ids)))

    @staticmethod
    def history_for_knowledge(
        db: Session,
        family_id: str,
        child_id: str,
        knowledge_ids: list[str],
        review_id: str | None = None,
        before: str | None = None,
    ) -> dict:
        ChildrenService.get_child(db, family_id, child_id)
        query = (
            select(ReviewItem, KnowledgeItem)
            .join(
                KnowledgeItem,
                ReviewItem.knowledge_item_id == KnowledgeItem.id,
            )
            .join(Subject, Subject.id == KnowledgeItem.subject_id)
            .where(
                ReviewItem.family_id == family_id,
                ReviewItem.child_id == child_id,
                KnowledgeItem.family_id == family_id,
                KnowledgeItem.id.in_(knowledge_ids),
                Subject.kind == "learning",
            )
        )
        if review_id:
            query = query.where(ReviewItem.id == review_id)
        rows = db.execute(query.order_by(KnowledgeItem.name, KnowledgeItem.id)).all()
        if review_id and not rows:
            raise NotFoundError("没有找到这条记录关联的复习")
        ids = [r.id for r, _ in rows]
        anchor = None
        if before:
            anchor = (
                db.scalar(
                    select(ReviewFeedback).where(
                        ReviewFeedback.id == before,
                        ReviewFeedback.family_id == family_id,
                        ReviewFeedback.review_item_id == review_id,
                    )
                )
                if review_id
                else None
            )
            if anchor is None:
                raise ValueError("反馈分页已失效，请重新展开")
        grouped: dict[str, list] = {}
        # A confirmed proposal contains at most 20 knowledge points. Reading four feedback
        # rows per review keeps this path bounded while avoiding a window/rank query that fails
        # in the cloud runtime despite compiling and passing against an isolated MySQL 8 image.
        for item_id in ids:
            feedback_query = select(ReviewFeedback).where(
                ReviewFeedback.family_id == family_id,
                ReviewFeedback.review_item_id == item_id,
            )
            if anchor is not None:
                feedback_query = feedback_query.where(
                    or_(
                        ReviewFeedback.occurred_at < anchor.occurred_at,
                        and_(
                            ReviewFeedback.occurred_at == anchor.occurred_at,
                            ReviewFeedback.id < anchor.id,
                        ),
                    )
                )
            feedbacks = db.scalars(
                feedback_query.order_by(
                    ReviewFeedback.occurred_at.desc(), ReviewFeedback.id.desc()
                ).limit(4)
            ).all()
            grouped[item_id] = []
            for feedback in feedbacks:
                occurred_at = feedback.occurred_at
                if occurred_at is None:  # Defensive guard for legacy/corrupt rows.
                    raise ValueError("复习反馈缺少发生时间")
                grouped[item_id].append(
                    {
                        "id": feedback.id,
                        "action": feedback.action,
                        "occurred_at": occurred_at.isoformat(),
                    }
                )
        return {
            "items": [
                {
                    "review_id": r.id,
                    "knowledge_id": k.id,
                    "name": k.name,
                    "active": r.active,
                    "due_date": r.due_date.isoformat(),
                    "is_due": r.active
                    and k.review_status == "normal"
                    and r.due_date <= local_date(),
                    "review_status": k.review_status,
                    "feedback": grouped.get(r.id, [])[:3],
                    "next_before": grouped[r.id][2]["id"]
                    if len(grouped.get(r.id, [])) > 3
                    else None,
                }
                for r, k in rows
            ]
        }

    @classmethod
    def daily_todos(
        cls, db: Session, family_id: str, child_id: str, day: date | None = None
    ) -> list[dict]:
        return cls.daily_todo_page(db, family_id, child_id, day, limit=50)["groups"]

    @classmethod
    def _legacy_daily_review_selection(
        cls,
        db: Session,
        family_id: str,
        child_id: str,
        day: date | None = None,
        *,
        known_child: Child | None = None,
    ) -> dict:
        """Return the bounded, stable Today projection without changing Review state."""
        child = known_child or ChildrenService.get_child(db, family_id, child_id)
        if child.family_id != family_id or child.id != child_id:
            raise NotFoundError("没有找到这个孩子")
        target = day or local_date()
        due_scope = (
            ReviewItem.family_id == family_id,
            ReviewItem.child_id == child_id,
            ReviewItem.active.is_(True),
            scheduling_eligible(),
            ReviewItem.due_date <= target,
            Subject.kind == "learning",
            Subject.active.is_(True),
        )

        def review_select(*columns):
            return (
                select(*columns)
                .select_from(ReviewItem)
                .join(KnowledgeItem, ReviewItem.knowledge_item_id == KnowledgeItem.id)
                .join(Subject, KnowledgeItem.subject_id == Subject.id)
            )

        aggregate = db.execute(
            review_select(
                func.count().label("total_due"),
                func.min(ReviewItem.due_date).label("earliest_due"),
            ).where(*due_scope)
        ).one()
        total_due = int(aggregate.total_due or 0)

        bounded_minutes = case(
            (KnowledgeItem.estimated_minutes < 1, 1),
            (KnowledgeItem.estimated_minutes > 5, 5),
            else_=KnowledgeItem.estimated_minutes,
        )
        day_start, day_end = local_day_bounds(target)
        usage_rows = db.execute(
            review_select(
                Subject.id.label("subject_id"),
                func.count(ReviewFeedback.id).label("used_count"),
                func.coalesce(func.sum(bounded_minutes), 0).label("used_minutes"),
            )
            .join(ReviewFeedback, ReviewFeedback.review_item_id == ReviewItem.id)
            .where(
                ReviewFeedback.family_id == family_id,
                ReviewItem.family_id == family_id,
                ReviewItem.child_id == child_id,
                Subject.kind == "learning",
                ReviewFeedback.occurred_at >= day_start,
                ReviewFeedback.occurred_at <= day_end,
            )
            .group_by(Subject.id)
        ).all()
        used_count = sum(int(row.used_count or 0) for row in usage_rows)
        used_minutes = sum(int(row.used_minutes or 0) for row in usage_rows)

        rows = list(
            db.execute(
                review_select(
                    ReviewItem.id.label("review_id"),
                    ReviewItem.due_date.label("due_date"),
                    ReviewItem.last_feedback.label("last_feedback"),
                    ReviewItem.step.label("step"),
                    ReviewItem.source_submission_id.label("source_submission_id"),
                    KnowledgeItem.id.label("knowledge_id"),
                    KnowledgeItem.name.label("knowledge_name"),
                    KnowledgeItem.evidence_json.label("evidence_json"),
                    KnowledgeItem.review_method.label("review_method"),
                    bounded_minutes.label("minutes"),
                    Subject.id.label("subject_id"),
                    Subject.name.label("subject_name"),
                    LearningSubmission.occurred_at.label("source_occurred_at"),
                    LearningSubmission.proposal_json.label("source_proposal"),
                )
                .outerjoin(
                    LearningSubmission,
                    and_(
                        LearningSubmission.id == ReviewItem.source_submission_id,
                        LearningSubmission.family_id == family_id,
                        LearningSubmission.child_id == child_id,
                    ),
                )
                .where(*due_scope)
                .order_by(ReviewItem.due_date.asc(), ReviewItem.id.asc())
                .limit(DAILY_REVIEW_CANDIDATE_LIMIT)
            ).mappings()
        )
        candidates: list[ReviewSelectionCandidate] = []
        for row in rows:
            source_summary, source_image_index = _confirmed_source_evidence(
                row["evidence_json"],
                row["source_submission_id"],
                row["knowledge_name"],
                row["source_proposal"],
            )
            candidates.append(
                ReviewSelectionCandidate(
                    review_id=str(row["review_id"]),
                    knowledge_id=str(row["knowledge_id"]),
                    subject_id=str(row["subject_id"]),
                    subject_name=str(row["subject_name"]),
                    knowledge_name=str(row["knowledge_name"]),
                    review_method=str(row["review_method"]),
                    estimated_minutes=int(row["minutes"]),
                    due_date=row["due_date"],
                    review_step=int(row["step"] or 0),
                    last_feedback=row["last_feedback"],
                    source_submission_id=row["source_submission_id"],
                    source_occurred_on=(
                        local_date(row["source_occurred_at"])
                        if row["source_occurred_at"] is not None
                        else None
                    ),
                    source_summary=source_summary,
                    source_image_index=source_image_index,
                    review_round=int(row["step"] or 0) + 1,
                )
            )
        selected = select_daily_reviews(
            candidates,
            budget_minutes=child.daily_budget_minutes or 15,
        )
        sessions: list[dict] = []
        by_subject: dict[str, dict] = {}
        for item in selected:
            session = by_subject.get(item.subject_id)
            if session is None:
                session = {
                    "id": f"{target.isoformat()}:{item.subject_id}",
                    "subject_id": item.subject_id,
                    "subject_name": item.subject_name,
                    "title": f"{item.subject_name}复习",
                    "estimated_minutes": 0,
                    "items": [],
                }
                by_subject[item.subject_id] = session
                sessions.append(session)
            session["estimated_minutes"] += item.bounded_minutes
            session["items"].append(
                {
                    "review_id": item.review_id,
                    "knowledge_id": item.knowledge_id,
                    "knowledge_name": item.knowledge_name,
                    "review_method": item.review_method,
                    "estimated_minutes": item.bounded_minutes,
                    "due_date": item.due_date.isoformat(),
                    "step": item.review_step,
                    "source_submission_id": item.source_submission_id,
                    "source_occurred_on": (
                        item.source_occurred_on.isoformat() if item.source_occurred_on else None
                    ),
                    "source_summary": item.source_summary,
                    "source_image_index": item.source_image_index,
                    "review_round": item.review_round,
                }
            )
        selected_minutes = sum(item.bounded_minutes for item in selected)
        return {
            "day": target.isoformat(),
            "sessions": sessions,
            "selected_count": len(selected),
            "selected_minutes": selected_minutes,
            "total_due": total_due,
            "backlog_count": max(0, total_due - len(selected)),
            "earliest_due": aggregate.earliest_due.isoformat() if aggregate.earliest_due else None,
            "today_feedback_count": used_count,
            "today_feedback_minutes": used_minutes,
            "policy_revision": DAILY_REVIEW_POLICY_REVISION,
        }

    @classmethod
    def daily_review_selection(
        cls,
        db: Session,
        family_id: str,
        child_id: str,
        day: date | None = None,
        *,
        known_child: Child | None = None,
    ) -> dict:
        """Materialize once and return the day's stable, minute-bounded review plan."""
        child = known_child or ChildrenService.get_child(db, family_id, child_id)
        if child.family_id != family_id or child.id != child_id:
            raise NotFoundError("没有找到这个孩子")
        target = day or local_date()
        plan = db.scalar(
            select(DailyReviewPlan).where(
                DailyReviewPlan.family_id == family_id,
                DailyReviewPlan.child_id == child_id,
                DailyReviewPlan.plan_date == target,
            )
        )
        if plan is None or (
            target == local_date()
            and plan.materialization_state == "provisional_empty"
            and plan.evaluated_inventory_revision != child.review_inventory_revision
        ):
            plan = cls._create_daily_review_plan(db, family_id, child, target)
        if plan.materialization_state == "fixed_early" and not db.info.get(
            "early_review_client_capable", True
        ):
            raise ClientUpgradeRequiredError("请更新小程序后查看今日提前安排")
        rows = list(
            db.execute(
                select(
                    DailyReviewPlanItem,
                    ReviewItem,
                    KnowledgeItem,
                    Subject,
                    LearningSubmission.occurred_at.label("source_occurred_at"),
                    LearningSubmission.proposal_json.label("source_proposal"),
                )
                .join(ReviewItem, ReviewItem.id == DailyReviewPlanItem.review_item_id)
                .join(KnowledgeItem, KnowledgeItem.id == ReviewItem.knowledge_item_id)
                .join(Subject, Subject.id == KnowledgeItem.subject_id)
                .outerjoin(
                    LearningSubmission,
                    and_(
                        LearningSubmission.id == ReviewItem.source_submission_id,
                        LearningSubmission.family_id == family_id,
                        LearningSubmission.child_id == child_id,
                    ),
                )
                .where(
                    DailyReviewPlanItem.plan_id == plan.id,
                    DailyReviewPlanItem.family_id == family_id,
                    DailyReviewPlanItem.child_id == child_id,
                    DailyReviewPlanItem.state != "rescheduled",
                    KnowledgeItem.family_id == family_id,
                    Subject.kind == "learning",
                )
                .order_by(DailyReviewPlanItem.ordinal, DailyReviewPlanItem.id)
                .limit(120)
            ).all()
        )
        sessions: list[dict] = []
        by_subject: dict[str, dict] = {}
        completed_count = 0
        completed_minutes = 0
        pending_count = 0
        pending_minutes = 0
        all_items: list[dict] = []
        for plan_item, review, knowledge, subject, source_occurred_at, source_proposal in rows:
            source_summary, source_image_index = _confirmed_source_evidence(
                knowledge.evidence_json,
                review.source_submission_id,
                knowledge.name,
                source_proposal,
            )
            snapshot = {
                "plan_item_id": plan_item.id,
                "review_id": review.id,
                "knowledge_id": knowledge.id,
                "knowledge_name": knowledge.name,
                "subject_name": subject.name,
                "review_method": knowledge.review_method,
                "estimated_minutes": int(plan_item.estimated_minutes),
                "due_date": review.due_date.isoformat(),
                "selection_kind": plan_item.selection_kind,
                "original_due_date": plan_item.original_due_date.isoformat()
                if plan_item.original_due_date
                else None,
                "step": int(review.step or 0),
                "state": plan_item.state,
                "state_version": int(review.state_version or 0),
                "last_reviewed_on": (
                    review.last_reviewed_on.isoformat() if review.last_reviewed_on else None
                ),
                "review_count": int(review.review_count or 0),
                "source_submission_id": review.source_submission_id,
                "source_occurred_on": (
                    local_date(source_occurred_at).isoformat()
                    if source_occurred_at is not None
                    else None
                ),
                "source_summary": source_summary,
                "source_image_index": source_image_index,
                "review_round": int(review.step or 0) + 1,
            }
            all_items.append(snapshot)
            # Completed rows still anchor their subject's original position in the plan.
            session = by_subject.get(subject.id)
            if session is None:
                session = {
                    "id": f"{plan.id}:{subject.id}",
                    "subject_id": subject.id,
                    "subject_name": subject.name,
                    "title": f"{subject.name}复习",
                    "estimated_minutes": 0,
                    "items": [],
                }
                by_subject[subject.id] = session
                sessions.append(session)
            if plan_item.state != "pending":
                completed_count += 1
                completed_minutes += int(plan_item.estimated_minutes)
                continue
            pending_count += 1
            pending_minutes += int(plan_item.estimated_minutes)
            session["estimated_minutes"] += int(plan_item.estimated_minutes)
            session["items"].append(
                {key: value for key, value in snapshot.items() if key != "subject_name"}
            )
        return {
            "plan_id": plan.id,
            "day": target.isoformat(),
            "sessions": [session for session in sessions if session["items"]],
            "all_items": all_items,
            "selected_count": pending_count,
            "planned_count": len(rows),
            "early_count": sum(pi.selection_kind == "early" for pi, *_ in rows),
            "early_minutes": sum(
                int(pi.estimated_minutes) for pi, *_ in rows if pi.selection_kind == "early"
            ),
            "selected_minutes": pending_minutes,
            "planned_minutes": int(plan.total_minutes or 0),
            "total_due": int(plan.due_count or 0),
            "backlog_count": max(0, int(plan.due_count or 0) - len(rows)),
            "earliest_due": plan.earliest_due.isoformat() if plan.earliest_due else None,
            "today_feedback_count": completed_count,
            "today_feedback_minutes": completed_minutes,
            "policy_revision": plan.policy_revision,
            "selection_policy": plan.policy_revision,
            "coverage_limited": (
                plan.covered_subject_count < plan.eligible_subject_count
                if plan.covered_subject_count is not None
                and plan.eligible_subject_count is not None
                else False
            ),
        }

    @staticmethod
    def _create_daily_review_plan(
        db: Session,
        family_id: str,
        child: Child,
        target: date,
    ) -> DailyReviewPlan:
        # Serialize plan materialization with confirmation and knowledge deletion. Recheck the
        # unique daily plan after waiting for another creator under MySQL REPEATABLE READ.
        locked_child = db.scalar(
            select(Child)
            .where(Child.id == child.id, Child.family_id == family_id)
            .with_for_update()
            .execution_options(populate_existing=True)
        )
        if locked_child is None:
            raise NotFoundError("没有找到这个孩子")
        child = locked_child
        existing = db.scalar(
            select(DailyReviewPlan)
            .where(
                DailyReviewPlan.family_id == family_id,
                DailyReviewPlan.child_id == child.id,
                DailyReviewPlan.plan_date == target,
            )
            .with_for_update()
        )
        if existing is not None and not (
            target == local_date()
            and existing.materialization_state == "provisional_empty"
            and existing.evaluated_inventory_revision != child.review_inventory_revision
        ):
            db.commit()
            return existing
        due_scope = (
            ReviewItem.family_id == family_id,
            ReviewItem.child_id == child.id,
            ReviewItem.active.is_(True),
            scheduling_eligible(),
            ReviewItem.due_date <= target,
            Subject.kind == "learning",
            Subject.active.is_(True),
        )
        aggregate = db.execute(
            select(
                func.count(ReviewItem.id),
                func.min(ReviewItem.due_date),
                func.count(func.distinct(Subject.id)),
            )
            .select_from(ReviewItem)
            .join(KnowledgeItem, ReviewItem.knowledge_item_id == KnowledgeItem.id)
            .join(Subject, KnowledgeItem.subject_id == Subject.id)
            .where(*due_scope)
            .with_for_update()
        ).one()
        selected = selected_candidates(
            db, family_id, str(child.id), target, int(child.daily_budget_minutes or 0), lock=True
        )
        early = False
        enabled = db.info.get("empty_day_early_review_enabled", False)
        if enabled and aggregate[0] == 0 and not db.info.get("early_review_client_capable", True):
            raise ClientUpgradeRequiredError("请更新小程序后查看今日安排")
        if enabled and aggregate[0] == 0 and child.active and not child.deleting:
            selected = select_early_reviews(
                db,
                family_id,
                str(child.id),
                target,
                int(child.daily_budget_minutes or 0),
                lock=True,
            )
            early = bool(selected)
        plan = existing or DailyReviewPlan(
            family_id=family_id,
            child_id=child.id,
            plan_date=target,
            budget_minutes=int(child.daily_budget_minutes or 15),
            total_minutes=sum(item.bounded_minutes for item in selected),
            due_count=int(aggregate[0] or 0),
            earliest_due=aggregate[1],
            eligible_subject_count=int(aggregate[2]),
            covered_subject_count=len({c.subject_id for c in selected}),
            policy_revision=DAILY_REVIEW_POLICY_REVISION,
        )
        plan.total_minutes = sum(item.bounded_minutes for item in selected)
        plan.due_count, plan.earliest_due = int(aggregate[0] or 0), aggregate[1]
        plan.eligible_subject_count = int(aggregate[2])
        plan.covered_subject_count = len({c.subject_id for c in selected})
        plan.materialization_state = (
            "fixed_early" if early else ("fixed_due" if aggregate[0] else "provisional_empty")
        )
        plan.evaluated_inventory_revision = int(child.review_inventory_revision or 0)
        if enabled:
            plan.policy_revision = EARLY_REVIEW_POLICY_REVISION
        db.add(plan)
        db.flush()
        for ordinal, item in enumerate(selected):
            db.add(
                DailyReviewPlanItem(
                    family_id=family_id,
                    child_id=child.id,
                    plan_id=plan.id,
                    review_item_id=item.review_id,
                    ordinal=ordinal,
                    estimated_minutes=item.bounded_minutes,
                    selection_kind="early" if early else "due",
                    original_due_date=item.due_date,
                    selected_review_version=item.state_version,
                )
            )
        try:
            record_offered(db, family_id, str(child.id), [c.review_id for c in selected], target)
            if selected:
                ChildrenService.invalidate_review_inventory(db, family_id, str(child.id))
            db.commit()
        except IntegrityError:
            db.rollback()
            existing = db.scalar(
                select(DailyReviewPlan).where(
                    DailyReviewPlan.family_id == family_id,
                    DailyReviewPlan.child_id == child.id,
                    DailyReviewPlan.plan_date == target,
                )
            )
            if existing is None:
                raise
            return existing
        return plan

    @classmethod
    def daily_todo_page(
        cls,
        db: Session,
        family_id: str,
        child_id: str,
        day: date | None = None,
        *,
        limit: int = 20,
        cursor: str | None = None,
        known_child: Child | None = None,
    ) -> dict:
        child = known_child or ChildrenService.get_child(db, family_id, child_id)
        if child.family_id != family_id or child.id != child_id:
            raise NotFoundError("没有找到这个孩子")
        target = day or local_date()
        scope = ("todos-v1", family_id, child_id, target.isoformat())
        anchor: dict[str, object] | None = None
        as_of = utcnow()
        if cursor:
            anchor = decode_cursor(cursor, scope)
            try:
                as_of = datetime.fromisoformat(str(anchor["as_of"]))
                anchor_due = date.fromisoformat(str(anchor["due_date"]))
                anchor_subject = str(anchor["subject_name"])
                anchor_method = str(anchor["review_method"])
                anchor_id = str(anchor["review_id"])
                if not as_of.tzinfo or not anchor_subject or not anchor_method or not anchor_id:
                    raise ValueError
            except (KeyError, TypeError, ValueError) as exc:
                raise ValueError("分页已失效，请刷新列表") from exc

        # MySQL 5.7 rejects window functions, so BUG-018's single OVER() projection is split into
        # bounded statements (BUG-SPEC-20260912-MYSQL57-01): an exact total COUNT, a budget-capped
        # ordering prefix, the anchored detail page, and — for cursor pages — one aggregate through
        # the anchor. Each read stays O(1) in page size and never materializes the whole due set.
        minutes = case(
            (KnowledgeItem.estimated_minutes < 1, 1), else_=KnowledgeItem.estimated_minutes
        )
        ordering = (
            ReviewItem.due_date.asc(),
            Subject.name.asc(),
            KnowledgeItem.review_method.asc(),
            ReviewItem.id.asc(),
        )
        budget = child.daily_budget_minutes or 15
        base_scope = (
            ReviewItem.family_id == family_id,
            ReviewItem.child_id == child_id,
            ReviewItem.active.is_(True),
            scheduling_eligible(),
            ReviewItem.due_date <= target,
            ReviewItem.updated_at <= as_of,
            Subject.kind == "learning",
        )

        def due_select(*columns):
            return (
                select(*columns)
                .select_from(ReviewItem)
                .join(KnowledgeItem, ReviewItem.knowledge_item_id == KnowledgeItem.id)
                .join(Subject, KnowledgeItem.subject_id == Subject.id)
                .where(*base_scope)
            )

        def detail_select():
            return due_select(
                ReviewItem.id.label("review_id"),
                ReviewItem.due_date.label("due_date"),
                ReviewItem.source_submission_id.label("source_submission_id"),
                ReviewItem.step.label("step"),
                ReviewItem.last_reviewed_on.label("last_reviewed_on"),
                KnowledgeItem.name.label("knowledge_name"),
                KnowledgeItem.id.label("knowledge_id"),
                KnowledgeItem.evidence_json.label("evidence_json"),
                KnowledgeItem.review_method.label("review_method"),
                minutes.label("minutes"),
                Subject.id.label("subject_id"),
                Subject.name.label("subject_name"),
                LearningSubmission.occurred_at.label("source_occurred_at"),
                LearningSubmission.proposal_json.label("source_proposal"),
            ).outerjoin(
                LearningSubmission,
                and_(
                    LearningSubmission.id == ReviewItem.source_submission_id,
                    LearningSubmission.family_id == family_id,
                    LearningSubmission.child_id == child_id,
                ),
            )

        def required_prefix(prefix_minutes) -> tuple[int, int]:
            # The required set is the total-order prefix whose running minutes stay within budget.
            # Budget is capped at 120 and every item costs >=1 minute, so <=121 rows decide it.
            running = 0
            required = 0
            estimated = 0
            for value in prefix_minutes:
                running += int(value)
                if running <= budget:
                    required += 1
                    estimated = running
                else:
                    break
            return required, estimated

        total_count = int(db.scalar(due_select(func.count())) or 0)

        if anchor is None:
            # First page: the detail page and the budget prefix are both leading prefixes of the
            # same order, so one bounded fetch (<=max(limit, budget)+1 rows) serves both.
            fetch_size = max(limit, budget) + 1
            leading = list(
                db.execute(detail_select().order_by(*ordering).limit(fetch_size)).mappings()
            )
            page_slice = leading[: limit + 1]
            more = len(page_slice) > limit
            rows = page_slice[:limit]
            required_count, estimated_minutes = required_prefix(
                row["minutes"] for row in leading[: budget + 1]
            )
            starting_minutes = 0
            preceding_count = 0
        else:
            prefix_minutes = db.scalars(
                due_select(minutes).order_by(*ordering).limit(budget + 1)
            ).all()
            required_count, estimated_minutes = required_prefix(prefix_minutes)
            preceding = db.execute(
                due_select(
                    func.count().label("preceding_count"),
                    func.coalesce(func.sum(minutes), 0).label("starting_minutes"),
                ).where(
                    or_(
                        ReviewItem.due_date < anchor_due,
                        and_(ReviewItem.due_date == anchor_due, Subject.name < anchor_subject),
                        and_(
                            ReviewItem.due_date == anchor_due,
                            Subject.name == anchor_subject,
                            KnowledgeItem.review_method < anchor_method,
                        ),
                        and_(
                            ReviewItem.due_date == anchor_due,
                            Subject.name == anchor_subject,
                            KnowledgeItem.review_method == anchor_method,
                            ReviewItem.id <= anchor_id,
                        ),
                    )
                )
            ).one()
            preceding_count = int(preceding.preceding_count or 0)
            starting_minutes = int(preceding.starting_minutes or 0)
            rows = list(
                db.execute(
                    detail_select()
                    .where(
                        or_(
                            ReviewItem.due_date > anchor_due,
                            and_(ReviewItem.due_date == anchor_due, Subject.name > anchor_subject),
                            and_(
                                ReviewItem.due_date == anchor_due,
                                Subject.name == anchor_subject,
                                KnowledgeItem.review_method > anchor_method,
                            ),
                            and_(
                                ReviewItem.due_date == anchor_due,
                                Subject.name == anchor_subject,
                                KnowledgeItem.review_method == anchor_method,
                                ReviewItem.id > anchor_id,
                            ),
                        )
                    )
                    .order_by(*ordering)
                    .limit(limit + 1)
                ).mappings()
            )
            more = len(rows) > limit
            rows = rows[:limit]
        items = []
        for row in rows:
            source_summary, source_image_index = _confirmed_source_evidence(
                row["evidence_json"],
                row["source_submission_id"],
                row["knowledge_name"],
                row["source_proposal"],
            )
            source_occurred_at = row["source_occurred_at"]
            source_occurred_on = (
                local_date(source_occurred_at) if source_occurred_at is not None else None
            )
            items.append(
                DueKnowledge(
                    review_id=str(row["review_id"]),
                    knowledge_id=str(row["knowledge_id"]),
                    subject_id=str(row["subject_id"]),
                    subject_name=str(row["subject_name"]),
                    knowledge_name=str(row["knowledge_name"]),
                    review_method=str(row["review_method"]),
                    estimated_minutes=int(row["minutes"]),
                    due_date=row["due_date"],
                    source_submission_id=row["source_submission_id"],
                    source_occurred_on=source_occurred_on,
                    source_summary=source_summary,
                    source_image_index=source_image_index,
                    review_round=(int(row["step"] or 0)) + 1,
                    interval_days=review_interval_days(
                        row["due_date"],
                        row["last_reviewed_on"],
                        source_occurred_on,
                    ),
                )
            )
        next_cursor = None
        if more and rows:
            last = rows[-1]
            next_cursor = encode_cursor(
                scope,
                {
                    "as_of": as_of.isoformat(),
                    "due_date": last["due_date"].isoformat(),
                    "subject_name": last["subject_name"],
                    "review_method": last["review_method"],
                    "review_id": last["review_id"],
                },
            )
        last_position = preceding_count + len(rows)
        return {
            "groups": group_daily_todos(
                items,
                budget,
                starting_minutes=starting_minutes,
            ),
            "total_count": total_count,
            "required_count": required_count,
            "estimated_minutes": estimated_minutes,
            "returned_count": len(rows),
            "remaining_count": max(0, total_count - last_position),
            "next_cursor": next_cursor,
        }

    @classmethod
    def upcoming_review_page(
        cls,
        db: Session,
        family_id: str,
        child_id: str,
        after: date | None = None,
        *,
        limit: int = 20,
        cursor: str | None = None,
        known_child: Child | None = None,
    ) -> dict | None:
        """Return one bounded page from the child's nearest future learning-review day."""
        child = known_child or ChildrenService.get_child(db, family_id, child_id)
        if child.family_id != family_id or child.id != child_id:
            raise NotFoundError("没有找到这个孩子")

        target = after or local_date()
        scope = ("upcoming-reviews-v1", family_id, child_id, target.isoformat())
        as_of = utcnow()
        anchor_subject = ""
        anchor_method = ""
        anchor_id = ""
        position = 0
        next_day: date | None = None
        if cursor:
            anchor = decode_cursor(cursor, scope)
            try:
                as_of = datetime.fromisoformat(str(anchor["as_of"]))
                next_day = date.fromisoformat(str(anchor["day"]))
                anchor_subject = str(anchor["subject_name"])
                anchor_method = str(anchor["review_method"])
                anchor_id = str(anchor["review_id"])
                raw_position = anchor["position"]
                if isinstance(raw_position, bool) or not isinstance(raw_position, (int, str)):
                    raise ValueError
                position = int(raw_position)
                if (
                    not as_of.tzinfo
                    or next_day <= target
                    or not anchor_subject
                    or not anchor_method
                    or not anchor_id
                    or position < 0
                ):
                    raise ValueError
            except (KeyError, TypeError, ValueError) as exc:
                raise ValueError("分页已失效，请重新展开") from exc

        future_scope = (
            ReviewItem.family_id == family_id,
            ReviewItem.child_id == child_id,
            ReviewItem.active.is_(True),
            scheduling_eligible(),
            ReviewItem.due_date > target,
            ReviewItem.updated_at <= as_of,
            Subject.kind == "learning",
        )

        def review_select(*columns):
            return (
                select(*columns)
                .select_from(ReviewItem)
                .join(KnowledgeItem, ReviewItem.knowledge_item_id == KnowledgeItem.id)
                .join(Subject, KnowledgeItem.subject_id == Subject.id)
            )

        if next_day is None:
            next_day = db.scalar(
                review_select(ReviewItem.due_date)
                .where(*future_scope)
                .order_by(ReviewItem.due_date.asc())
                .limit(1)
            )
            if next_day is None:
                return None

        day_scope = (
            ReviewItem.family_id == family_id,
            ReviewItem.child_id == child_id,
            ReviewItem.active.is_(True),
            scheduling_eligible(),
            ReviewItem.due_date == next_day,
            ReviewItem.updated_at <= as_of,
            Subject.kind == "learning",
        )
        minutes = case(
            (KnowledgeItem.estimated_minutes < 1, 1), else_=KnowledgeItem.estimated_minutes
        )
        ordering = (
            Subject.name.asc(),
            KnowledgeItem.review_method.asc(),
            ReviewItem.id.asc(),
        )
        aggregate = db.execute(
            review_select(
                func.count().label("total_count"),
                func.coalesce(func.sum(minutes), 0).label("estimated_minutes"),
            ).where(*day_scope)
        ).one()
        total_count = int(aggregate.total_count or 0)
        estimated_minutes = int(aggregate.estimated_minutes or 0)

        details = review_select(
            ReviewItem.id.label("review_id"),
            ReviewItem.due_date.label("due_date"),
            ReviewItem.source_submission_id.label("source_submission_id"),
            KnowledgeItem.name.label("knowledge_name"),
            KnowledgeItem.review_method.label("review_method"),
            minutes.label("minutes"),
            Subject.id.label("subject_id"),
            Subject.name.label("subject_name"),
        ).where(*day_scope)
        if cursor:
            details = details.where(
                or_(
                    Subject.name > anchor_subject,
                    and_(
                        Subject.name == anchor_subject,
                        KnowledgeItem.review_method > anchor_method,
                    ),
                    and_(
                        Subject.name == anchor_subject,
                        KnowledgeItem.review_method == anchor_method,
                        ReviewItem.id > anchor_id,
                    ),
                )
            )
        fetched = list(db.execute(details.order_by(*ordering).limit(limit + 1)).mappings())
        more = len(fetched) > limit
        rows = fetched[:limit]

        groups: list[dict] = []
        grouped: dict[tuple[str, str], dict] = {}
        for row in rows:
            group_key = (str(row["subject_id"]), str(row["review_method"]))
            group = grouped.get(group_key)
            if group is None:
                group = {
                    "id": f"{group_key[0]}:{group_key[1]}:scheduled:{next_day.isoformat()}",
                    "subject_id": group_key[0],
                    "subject_name": str(row["subject_name"]),
                    "review_method": group_key[1],
                    "estimated_minutes": 0,
                    "items": [],
                }
                grouped[group_key] = group
                groups.append(group)
            item_minutes = int(row["minutes"])
            group["estimated_minutes"] += item_minutes
            group["items"].append(
                {
                    "review_id": str(row["review_id"]),
                    "knowledge_name": str(row["knowledge_name"]),
                    "estimated_minutes": item_minutes,
                    "due_date": row["due_date"].isoformat(),
                    "source_submission_id": row["source_submission_id"],
                }
            )

        next_cursor = None
        if more and rows:
            last = rows[-1]
            next_cursor = encode_cursor(
                scope,
                {
                    "as_of": as_of.isoformat(),
                    "day": next_day.isoformat(),
                    "subject_name": last["subject_name"],
                    "review_method": last["review_method"],
                    "review_id": last["review_id"],
                    "position": position + len(rows),
                },
            )
        returned_position = position + len(rows)
        return {
            "day": next_day.isoformat(),
            "groups": groups,
            "total_count": total_count,
            "estimated_minutes": estimated_minutes,
            "returned_count": len(rows),
            "remaining_count": max(0, total_count - returned_position),
            "next_cursor": next_cursor,
        }

    @classmethod
    def pending_review_loads(
        cls,
        db: Session,
        target: date,
        *,
        family_id: str | None = None,
        child_ids: set[str] | None = None,
    ) -> list[PendingReviewLoad]:
        """Outstanding review per active child across families, for the evening digest.

        Only learning subjects count, matching `daily_todos`; activities never create review debt.
        """
        rows = db.execute(
            select(
                ReviewItem.family_id,
                ReviewItem.child_id,
                Child.name,
                Subject.name,
                func.count(ReviewItem.id),
            )
            .join(KnowledgeItem, ReviewItem.knowledge_item_id == KnowledgeItem.id)
            .join(Subject, KnowledgeItem.subject_id == Subject.id)
            .join(Child, ReviewItem.child_id == Child.id)
            .where(
                ReviewItem.active.is_(True),
                scheduling_eligible(),
                ReviewItem.due_date <= target,
                Subject.kind == "learning",
                Child.active.is_(True),
                Child.deleting.is_(False),
                *([ReviewItem.family_id == family_id] if family_id is not None else []),
                *([ReviewItem.child_id.in_(child_ids)] if child_ids is not None else []),
            )
            .group_by(ReviewItem.family_id, ReviewItem.child_id, Child.name, Subject.name)
            .order_by(func.count(ReviewItem.id).desc(), Subject.name)
        ).all()
        totals: dict[tuple[str, str], PendingReviewLoad] = {}
        for family_id, child_id, child_name, subject_name, count in rows:
            key = (str(family_id), str(child_id))
            current = totals.get(key)
            if current is None:
                totals[key] = PendingReviewLoad(
                    family_id=str(family_id),
                    child_id=str(child_id),
                    child_name=str(child_name),
                    pending_count=int(count or 0),
                    subject_names=(str(subject_name),),
                )
                continue
            totals[key] = PendingReviewLoad(
                family_id=current.family_id,
                child_id=current.child_id,
                child_name=current.child_name,
                pending_count=current.pending_count + int(count or 0),
                subject_names=(*current.subject_names, str(subject_name)),
            )
        return list(totals.values())

    @staticmethod
    def record_review_event(
        db: Session,
        *,
        family_id: str,
        review: ReviewItem,
        action: str,
        reviewed_on: date,
        source: str,
        reactivate: bool = False,
    ) -> ReviewPolicyTransition:
        """Atomically stage one audit event, projection update, and same-day plan status."""
        if review.family_id != family_id:
            raise NotFoundError("没有找到这条复习任务")
        if not review.active and not reactivate:
            raise ConflictError("这条复习已结束，请刷新列表后再操作")
        if review.due_date is None:
            raise ValueError("复习任务缺少计划日期")
        plan_item = db.scalar(
            select(DailyReviewPlanItem)
            .join(DailyReviewPlan, DailyReviewPlan.id == DailyReviewPlanItem.plan_id)
            .where(
                DailyReviewPlanItem.family_id == family_id,
                DailyReviewPlanItem.child_id == review.child_id,
                DailyReviewPlanItem.review_item_id == review.id,
                DailyReviewPlan.family_id == family_id,
                DailyReviewPlan.child_id == review.child_id,
                DailyReviewPlan.plan_date == reviewed_on,
            )
            .with_for_update()
            .execution_options(populate_existing=True)
        )
        if (
            source == "manual"
            and review.due_date > reviewed_on
            and (
                plan_item is None
                or plan_item.state != "pending"
                or plan_item.selection_kind != "early"
                or plan_item.original_due_date != review.due_date
                or plan_item.selected_review_version != review.state_version
            )
        ):
            reservation = db.scalar(
                select(ReviewScheduleOverride.review_item_id)
                .where(
                    ReviewScheduleOverride.family_id == family_id,
                    ReviewScheduleOverride.child_id == review.child_id,
                    ReviewScheduleOverride.review_item_id == review.id,
                )
                .limit(1)
            )
            same_day_due_feedback = review.last_reviewed_on == reviewed_on and (
                plan_item is None or plan_item.selection_kind == "due"
            )
            if not reservation and not same_day_due_feedback:
                raise ConflictError("这条提前安排已有变化，请刷新后重试")
        state = ReviewState(
            step=0 if reactivate and not review.active else int(review.step or 0),
            due_date=review.due_date,
            active=True if reactivate else bool(review.active),
            last_reviewed_on=review.last_reviewed_on,
            review_count=int(review.review_count or 0),
            interval_days=max(1, int(review.interval_days or 1)),
            heat_milli=max(0, int(review.heat_milli or 0)),
            lapse_count=max(0, int(review.lapse_count or 0)),
            state_version=max(0, int(review.state_version or 0)),
        )
        arrangement = consume_arrangement(db, family_id, review, reviewed_on, action)
        policy_state = state
        if arrangement == "consumed" and state.last_reviewed_on == reviewed_on:
            # The parent's date is a reservation, not a new automatic curve interval.
            # Repeated same-day events must use the unchanged interval of the actual review.
            policy_state = replace(
                state, due_date=reviewed_on + timedelta(days=state.interval_days)
            )
        transition = apply_review_event(policy_state, action, reviewed_on)  # type: ignore[arg-type]
        if arrangement == "preserve":
            transition = replace(
                transition,
                step=state.step,
                due_date=state.due_date,
                active=state.active,
                last_reviewed_on=state.last_reviewed_on,
                interval_days=state.interval_days,
                heat_milli=state.heat_milli,
                lapse_count=state.lapse_count,
                advanced=False,
            )
        review.step = transition.step
        review.due_date = transition.due_date
        review.active = transition.active
        review.last_reviewed_on = transition.last_reviewed_on
        review.review_count = transition.review_count
        review.interval_days = transition.interval_days
        review.heat_milli = transition.heat_milli
        review.lapse_count = transition.lapse_count
        review.policy_revision = CURVE_HEAT_POLICY_REVISION
        review.state_version = transition.state_version
        review.last_feedback = action
        reset_queue(review, local_date(), deferred=action == "defer")
        db.add(
            ReviewFeedback(
                family_id=family_id,
                review_item_id=review.id,
                action=action,
                reviewed_on=reviewed_on if action != "defer" else None,
                source=source,
                policy_revision=CURVE_HEAT_POLICY_REVISION,
                before_step=state.step,
                after_step=transition.step,
                before_interval_days=state.interval_days,
                after_interval_days=transition.interval_days,
                before_due_date=state.due_date,
                after_due_date=transition.due_date,
            )
        )
        if plan_item is not None and plan_item.state == "pending":
            plan_item.state = {
                "complete": "complete",
                "observed": "complete",
                "partial": "partial",
                "reinforce": "reinforce",
                "defer": "deferred",
            }[action]
        ChildrenService.invalidate_review_inventory(db, family_id, str(review.child_id))
        return transition

    @staticmethod
    def feedback(
        db: Session,
        family_id: str,
        review_id: str,
        action: str,
        idempotency_key: str | None = None,
        *,
        member_id: str | None = None,
    ) -> dict:
        # Feedback closes a review item that already exists, so it is scoped by review id and
        # family only. An archived profile keeps accepting feedback on purpose (`BHV-025`);
        # the deterministic planner never creates new review items here.
        child_id = db.scalar(
            select(ReviewItem.child_id).where(
                ReviewItem.id == review_id, ReviewItem.family_id == family_id
            )
        )
        db.scalar(
            select(Child)
            .where(Child.id == child_id, Child.family_id == family_id)
            .with_for_update()
        )
        review = db.scalar(
            select(ReviewItem)
            .join(KnowledgeItem, ReviewItem.knowledge_item_id == KnowledgeItem.id)
            .join(Subject, KnowledgeItem.subject_id == Subject.id)
            .where(
                ReviewItem.id == review_id,
                ReviewItem.family_id == family_id,
                Subject.kind == "learning",
            )
            .with_for_update()
        )
        if review is None:
            raise NotFoundError("没有找到这条复习任务")
        if idempotency_key:
            existing = db.scalar(
                select(ReviewFeedbackRequest).where(
                    ReviewFeedbackRequest.family_id == family_id,
                    ReviewFeedbackRequest.idempotency_key == idempotency_key,
                )
            )
            if existing is not None:
                if existing.review_item_id != review_id or existing.action != action:
                    raise ConflictError("此反馈标识已用于不同操作，请重新操作")
                return PlanningService._feedback_result(existing)
        transition = PlanningService.record_review_event(
            db,
            family_id=family_id,
            review=review,
            action=action,
            reviewed_on=local_date(),
            source="manual",
        )
        if action == "complete" and member_id:
            record_completion(
                db, family_id, member_id, str(review.id), str(review.child_id), local_date()
            )
        if idempotency_key:
            db.add(
                ReviewFeedbackRequest(
                    family_id=family_id,
                    idempotency_key=idempotency_key,
                    review_item_id=review.id,
                    action=action,
                    result_step=review.step,
                    result_due_date=review.due_date,
                    result_active=review.active,
                )
            )
        try:
            db.commit()
        except IntegrityError:
            db.rollback()
            if not idempotency_key:
                raise
            existing = db.scalar(
                select(ReviewFeedbackRequest).where(
                    ReviewFeedbackRequest.family_id == family_id,
                    ReviewFeedbackRequest.idempotency_key == idempotency_key,
                )
            )
            if existing is None:
                raise
            if existing.review_item_id != review_id or existing.action != action:
                raise ConflictError("此反馈标识已用于不同操作，请重新操作") from None
            return PlanningService._feedback_result(existing)
        return {
            "review_id": review.id,
            "action": action,
            "step": review.step,
            "due_date": transition.due_date.isoformat(),
            "active": review.active,
        }

    @staticmethod
    def feedback_batch(
        db: Session,
        family_id: str,
        child_id: str,
        items: list[dict[str, str]],
        idempotency_key: str,
    ) -> dict:
        """Apply all selected feedback in one transaction, with byte-stable replay."""
        db.scalar(
            select(Child)
            .where(Child.id == child_id, Child.family_id == family_id)
            .with_for_update()
        )
        ChildrenService.get_child(db, family_id, child_id)
        review_ids = [item["review_id"] for item in items]
        if len(review_ids) != len(set(review_ids)):
            raise ValueError("批量反馈不能包含重复复习项")
        canonical = json.dumps(items, ensure_ascii=False, separators=(",", ":"))
        fingerprint = sha256(canonical.encode()).hexdigest()
        existing_batch = db.scalar(
            select(ReviewFeedbackBatchRequest).where(
                ReviewFeedbackBatchRequest.family_id == family_id,
                ReviewFeedbackBatchRequest.idempotency_key == idempotency_key,
            )
        )
        if existing_batch is not None:
            if (
                existing_batch.child_id != child_id
                or existing_batch.request_fingerprint != fingerprint
            ):
                raise ConflictError("此批量反馈标识已用于不同操作，请重新操作")
            if existing_batch.result_json is None:
                raise RuntimeError("batch feedback replay has no stored result")
            result = json.loads(existing_batch.result_json)
            result["replayed"] = True
            return result

        rows = list(
            db.scalars(
                select(ReviewItem)
                .join(KnowledgeItem, ReviewItem.knowledge_item_id == KnowledgeItem.id)
                .join(Subject, KnowledgeItem.subject_id == Subject.id)
                .where(
                    ReviewItem.id.in_(review_ids),
                    ReviewItem.family_id == family_id,
                    ReviewItem.child_id == child_id,
                    Subject.kind == "learning",
                )
                .order_by(ReviewItem.id)
                .with_for_update()
                .execution_options(populate_existing=True)
            )
        )
        by_id = {row.id: row for row in rows}
        if len(by_id) != len(review_ids):
            raise NotFoundError("批量反馈中有无法访问的复习项")
        today = local_date()
        if any(not row.active or row.due_date is None for row in rows):
            raise ConflictError("批量复习状态已变化，请刷新后重试")

        results: list[dict] = []
        for item in items:
            review = by_id[item["review_id"]]
            action = item["action"]
            transition = PlanningService.record_review_event(
                db,
                family_id=family_id,
                review=review,
                action=action,
                reviewed_on=today,
                source="manual",
            )
            results.append(
                {
                    "review_id": review.id,
                    "action": action,
                    "step": transition.step,
                    "due_date": transition.due_date.isoformat(),
                    "active": transition.active,
                }
            )
        response = {"items": results, "replayed": False}
        db.add(
            ReviewFeedbackBatchRequest(
                family_id=family_id,
                child_id=child_id,
                idempotency_key=idempotency_key,
                request_fingerprint=fingerprint,
                result_json=json.dumps(response, ensure_ascii=False, separators=(",", ":")),
            )
        )
        try:
            db.commit()
        except IntegrityError:
            db.rollback()
            replay = db.scalar(
                select(ReviewFeedbackBatchRequest).where(
                    ReviewFeedbackBatchRequest.family_id == family_id,
                    ReviewFeedbackBatchRequest.idempotency_key == idempotency_key,
                )
            )
            if replay is None:
                raise
            if replay.child_id != child_id or replay.request_fingerprint != fingerprint:
                raise ConflictError("此批量反馈标识已用于不同操作，请重新操作") from None
            if replay.result_json is None:
                raise RuntimeError("batch feedback replay has no stored result") from None
            response = json.loads(replay.result_json)
            response["replayed"] = True
            return response
        return response

    @staticmethod
    def _feedback_result(request: ReviewFeedbackRequest) -> dict:
        if request.result_due_date is None:
            raise RuntimeError("feedback request has no stored due date")
        return {
            "review_id": request.review_item_id,
            "action": request.action,
            "step": request.result_step,
            "due_date": request.result_due_date.isoformat(),
            "active": request.result_active,
        }

    @staticmethod
    def practice_materials(
        db: Session,
        family_id: str,
        child_id: str,
        limit: int = 5,
        review_ids: list[str] | None = None,
    ) -> dict:
        ChildrenService.get_child(db, family_id, child_id)
        query = (
            select(KnowledgeItem, Subject)
            .join(ReviewItem, ReviewItem.knowledge_item_id == KnowledgeItem.id)
            .join(Subject, KnowledgeItem.subject_id == Subject.id)
            .where(
                KnowledgeItem.family_id == family_id,
                KnowledgeItem.child_id == child_id,
                ReviewItem.active.is_(True),
                scheduling_eligible(),
                Subject.kind == "learning",
            )
            .order_by(ReviewItem.due_date)
            .limit(limit)
        )
        if review_ids:
            query = query.where(ReviewItem.id.in_(review_ids))
        rows = db.execute(query).all()
        prompts = []
        for knowledge, subject in rows:
            prompt = {
                "数学": f"请孩子不用看答案，讲一讲“{knowledge.name}”，再做一道同类例题。",
                "英语": f"请孩子听、说、读、拼“{knowledge.name}”，家长只提示不代答。",
                "语文": f"请孩子认读或听写“{knowledge.name}”，再用自己的话解释。",
            }.get(subject.name, f"请孩子用自己的话回顾“{knowledge.name}”。")
            prompts.append(
                {"subject_name": subject.name, "knowledge_name": knowledge.name, "prompt": prompt}
            )
        return {
            "title": "今天的家长带练清单",
            "items": prompts,
            "disclaimer": "用于提示复习，不自动判分。",
        }
