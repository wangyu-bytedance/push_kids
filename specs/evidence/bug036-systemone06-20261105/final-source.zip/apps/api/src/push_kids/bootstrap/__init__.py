"""Application composition root."""
