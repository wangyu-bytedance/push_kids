"""SQLAlchemy persistence model."""
