"""Deterministic review planning."""
