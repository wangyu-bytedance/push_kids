"""Private media persistence."""
