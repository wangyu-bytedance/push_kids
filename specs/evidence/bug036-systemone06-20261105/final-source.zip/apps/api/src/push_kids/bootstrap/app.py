from __future__ import annotations

import asyncio
import logging
import sys
from contextlib import asynccontextmanager, suppress
from time import perf_counter
from typing import TextIO

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from push_kids.activities.router import router as activities_router
from push_kids.agent_processing.coverage_worker import CoverageWorker
from push_kids.agent_processing.footprint_provider import build_footprint_provider
from push_kids.agent_processing.providers import build_provider
from push_kids.agent_processing.suggestion_provider import build_suggestion_provider
from push_kids.agent_processing.worker import AnalysisWorker
from push_kids.children.router import router as children_router
from push_kids.daily_tasks.router import router as daily_tasks_router
from push_kids.data_management.router import router as data_management_router
from push_kids.data_management.worker import DataDeletionWorker
from push_kids.families.rate_limit import InvitePreviewRateLimiter
from push_kids.families.router import router as families_router
from push_kids.footprints.map_provider import TencentPlaces
from push_kids.footprints.router import router as footprints_router
from push_kids.footprints.worker import FootprintWorker
from push_kids.learning.router import router as learning_router
from push_kids.learning_suggestions.router import router as suggestions_router
from push_kids.learning_suggestions.worker import SuggestionWorker
from push_kids.media.preview_limit import MediaPreviewLimiter
from push_kids.media.store import build_media_store
from push_kids.notifications.router import router as notifications_router
from push_kids.notifications.scheduler import NotificationScheduler
from push_kids.notifications.service import build_channel
from push_kids.planning.router import router as planning_router
from push_kids.platform.config import Settings, get_settings
from push_kids.platform.database import Database
from push_kids.platform.errors import AppError
from push_kids.reporting.router import router as reporting_router
from push_kids.travel.router import router as travel_router

logger = logging.getLogger("push_kids")
_CLOUD_HANDLER_MARKER = "_push_kids_cloud_handler"


def configure_cloud_logging(stream: TextIO | None = None) -> None:
    """Route application INFO events to cloud stderr without changing root logging."""
    application_logger = logging.getLogger("push_kids")
    application_logger.setLevel(logging.INFO)
    has_cloud_handler = any(
        getattr(item, _CLOUD_HANDLER_MARKER, False) for item in application_logger.handlers
    )
    if has_cloud_handler:
        return
    handler = logging.StreamHandler(stream or sys.stderr)
    handler.setLevel(logging.INFO)
    handler.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
    setattr(handler, _CLOUD_HANDLER_MARKER, True)
    application_logger.addHandler(handler)
    application_logger.propagate = False


def create_app(settings: Settings | None = None) -> FastAPI:
    config = settings or get_settings()
    if config.is_cloud:
        configure_cloud_logging()
    config.validate_cloud_runtime()
    database = Database(config)
    provider = build_provider(config)
    media_store = build_media_store(config)
    worker = AnalysisWorker(database, provider, media_store, config.worker_poll_seconds)
    coverage_worker = CoverageWorker(database, provider)
    suggestion_worker = SuggestionWorker(database, build_suggestion_provider(config))
    deletion_worker = DataDeletionWorker(database, media_store, config.worker_poll_seconds)
    footprint_places = TencentPlaces(
        config.footprint_map_key.get_secret_value() if config.footprint_map_key else None
    )
    footprint_worker = FootprintWorker(
        database,
        media_store,
        build_footprint_provider(config),
        footprint_places,
        max(config.worker_poll_seconds, 1),
    )
    notification_channel = build_channel(config)
    notification_scheduler = NotificationScheduler(
        database, notification_channel, config.notification_tick_seconds
    )

    def worker_done(task: asyncio.Task) -> None:
        if not task.cancelled():
            error = task.exception()
            if error is not None:
                logger.warning("worker_task_exited error_type=%s", type(error).__name__)

    def scheduler_done(task: asyncio.Task) -> None:
        if not task.cancelled():
            error = task.exception()
            if error is not None:
                logger.warning("notification_scheduler_exited error_type=%s", type(error).__name__)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        if config.is_cloud:
            database.verify_cloud_schema()
        else:
            config.media_root.mkdir(parents=True, exist_ok=True)
            database.create_schema()
        task = asyncio.create_task(worker.run()) if config.run_worker else None
        coverage_task = asyncio.create_task(coverage_worker.run()) if config.run_worker else None
        app.state.coverage_worker_task = coverage_task
        suggestion_task = (
            asyncio.create_task(suggestion_worker.run()) if config.run_worker else None
        )
        app.state.suggestion_worker_task = suggestion_task
        deletion_task = asyncio.create_task(deletion_worker.run()) if config.run_worker else None
        footprint_task = asyncio.create_task(footprint_worker.run()) if config.run_worker else None
        app.state.footprint_worker_task = footprint_task
        app.state.worker_task = task
        app.state.deletion_worker_task = deletion_task
        for running_task in (task, deletion_task, footprint_task, coverage_task, suggestion_task):
            if running_task:
                running_task.add_done_callback(worker_done)
        # Reminders are only scheduled where a channel exists, so an unconfigured deployment does
        # not spend database work producing rows that could never be sent.
        scheduler_task = (
            asyncio.create_task(notification_scheduler.run())
            if config.run_notification_scheduler and notification_channel.available
            else None
        )
        app.state.notification_scheduler_task = scheduler_task
        if scheduler_task:
            scheduler_task.add_done_callback(scheduler_done)
        try:
            yield
        finally:
            try:
                if suggestion_task:
                    suggestion_worker.stop()
                    with suppress(asyncio.CancelledError, Exception):
                        await suggestion_task
                if coverage_task:
                    coverage_worker.stop()
                    with suppress(asyncio.CancelledError, Exception):
                        await coverage_task
                if footprint_task:
                    footprint_worker.stop()
                    with suppress(asyncio.CancelledError, Exception):
                        await footprint_task
                if scheduler_task:
                    notification_scheduler.stop()
                    with suppress(asyncio.CancelledError, Exception):
                        await scheduler_task
                if task:
                    worker.stop()
                    # The completion callback consumes and safely reports task failure.
                    with suppress(asyncio.CancelledError, Exception):
                        await task
                if deletion_task:
                    deletion_worker.stop()
                    with suppress(asyncio.CancelledError, Exception):
                        await deletion_task
            finally:
                database.engine.dispose()

    app = FastAPI(
        title="Push Kids API",
        version="0.1.0",
        description="家长确认驱动的小学生学习记录、复习计划与活动跟进 API",
        lifespan=lifespan,
        docs_url=None if config.is_cloud else "/docs",
        redoc_url=None if config.is_cloud else "/redoc",
        openapi_url=None if config.is_cloud else "/openapi.json",
    )
    app.state.settings = config
    app.state.suggestion_worker = suggestion_worker
    app.state.database = database
    app.state.analysis_provider = provider
    app.state.media_store = media_store
    app.state.media_preview_limiter = MediaPreviewLimiter()
    app.state.coverage_worker = coverage_worker
    app.state.coverage_worker_task = None
    app.state.worker = worker
    app.state.worker_task = None
    app.state.deletion_worker = deletion_worker
    app.state.deletion_worker_task = None
    app.state.footprint_worker = footprint_worker
    app.state.footprint_worker_task = None
    app.state.footprint_places = footprint_places
    app.state.invite_preview_limiter = InvitePreviewRateLimiter()
    app.state.notification_channel = notification_channel
    app.state.notification_scheduler = notification_scheduler
    app.state.notification_scheduler_task = None
    if config.cors_origin_list:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=config.cors_origin_list,
            allow_methods=["GET", "POST", "PATCH", "DELETE"],
            allow_headers=["Content-Type", "X-Family-ID", "X-Debug-Actor", "Idempotency-Key"],
        )

    @app.middleware("http")
    async def enforce_cloud_request_limit(request: Request, call_next):
        started = perf_counter()
        if config.is_cloud:
            content_length = request.headers.get("content-length")
            if content_length and content_length.isdigit() and int(content_length) > 100 * 1024:
                response = JSONResponse(
                    status_code=413,
                    content={
                        "error": {
                            "code": "request_too_large",
                            "message": "云托管接口请求体不能超过 100KB，图片请直传对象存储",
                        }
                    },
                )
            else:
                response = await call_next(request)
        else:
            response = await call_next(request)
        duration_ms = round((perf_counter() - started) * 1000, 2)
        response_length = response.headers.get("content-length")
        response_bytes = (
            int(response_length) if response_length and response_length.isdigit() else None
        )
        route = request.scope.get("route")
        route_template = getattr(route, "path", "unmatched")
        event_name = (
            "api_read_budget_exceeded"
            if duration_ms >= 500 or (response_bytes is not None and response_bytes >= 128 * 1024)
            else "api_request_completed"
        )
        logger.log(
            logging.WARNING if event_name == "api_read_budget_exceeded" else logging.INFO,
            "%s method=%s route=%s status=%s duration_ms=%.2f response_bytes=%s",
            event_name,
            request.method,
            route_template,
            response.status_code,
            duration_ms,
            response_bytes if response_bytes is not None else "unknown",
        )
        return response

    @app.exception_handler(AppError)
    async def handle_app_error(_request: Request, exc: AppError) -> JSONResponse:
        return JSONResponse(
            status_code=exc.status_code,
            content={"error": {"code": exc.code, "message": exc.message}},
        )

    @app.exception_handler(ValueError)
    async def handle_value_error(_request: Request, exc: ValueError) -> JSONResponse:
        return JSONResponse(
            status_code=400,
            content={"error": {"code": "invalid_input", "message": str(exc)}},
        )

    @app.get("/health", tags=["system"])
    def health() -> dict[str, str]:
        return {"status": "ok", "ai_provider": config.ai_provider}

    @app.get("/health/live", tags=["system"])
    def health_live() -> dict[str, str]:
        return {"status": "ok"}

    @app.get("/health/ready", tags=["system"])
    def health_ready():
        database.check_ready()
        if config.is_cloud:
            database.verify_cloud_schema()
        task = app.state.worker_task
        deletion_task = app.state.deletion_worker_task
        if config.run_worker and (
            task is None
            or task.done()
            or not worker.is_ready
            or deletion_task is None
            or deletion_task.done()
            or not deletion_worker.is_ready
            or app.state.footprint_worker_task is None
            or app.state.footprint_worker_task.done()
            or not footprint_worker.is_ready
        ):
            return JSONResponse(
                status_code=503,
                content={
                    "error": {
                        "code": "worker_unavailable",
                        "message": "分析任务执行器暂不可用",
                    }
                },
            )
        return {"status": "ready"}

    api_prefix = "/api/v1"
    app.include_router(children_router, prefix=api_prefix)
    app.include_router(daily_tasks_router, prefix=api_prefix)
    app.include_router(data_management_router, prefix=api_prefix)
    app.include_router(families_router, prefix=api_prefix)
    app.include_router(learning_router, prefix=api_prefix)
    app.include_router(suggestions_router, prefix=api_prefix)
    app.include_router(planning_router, prefix=api_prefix)
    app.include_router(activities_router, prefix=api_prefix)
    app.include_router(travel_router, prefix=api_prefix)
    app.include_router(reporting_router, prefix=api_prefix)
    app.include_router(notifications_router, prefix=api_prefix)
    app.include_router(footprints_router, prefix=api_prefix)
    return app
