"""Disposable local MySQL5.7 gate; credentials never leave this private process."""
import json
import os
import secrets
import subprocess
import time
from pathlib import Path

os.umask(0o077)
ROOT = Path('/Users/bytedance/Documents/push_kids')
SAFE = Path('/private/tmp/push-kids-systemone06-20261105')
PRIVATE = SAFE
name = 'push-kids-systemone06-' + secrets.token_hex(4)
password = secrets.token_hex(24)
env = dict(os.environ, MYSQL_ROOT_PASSWORD=password)
status = {'image': 'public.ecr.aws/docker/library/mysql:5.7', 'production_access': False, 'container_removed': False}


def run(args, **kwargs):
    return subprocess.run(args, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, **kwargs)


try:
    launched = run(['docker', 'run', '-d', '--name', name, '--memory', '1g', '--cpus', '1', '-p', '127.0.0.1::3306', '-e', 'MYSQL_ROOT_PASSWORD', '-e', 'MYSQL_ROOT_HOST=%', '-e', 'MYSQL_DATABASE=systemone_gate', status['image'], '--character-set-server=utf8mb4', '--collation-server=utf8mb4_unicode_ci'], env=env)
    if launched.returncode:
        raise RuntimeError('container_start_failed')
    port = run(['docker', 'inspect', '--format', '{{(index (index .NetworkSettings.Ports "3306/tcp") 0).HostPort}}', name]).stdout.strip()
    url = f'mysql+pymysql://root:{password}@127.0.0.1:{port}/systemone_gate?charset=utf8mb4'
    import pymysql
    ready = False
    for _ in range(120):
        try:
            db = pymysql.connect(host='127.0.0.1', port=int(port), user='root', password=password, database='systemone_gate', connect_timeout=1)
            with db.cursor() as c:
                c.execute('SELECT VERSION()'); status['server_version'] = c.fetchone()[0]
            db.close(); ready = True; break
        except Exception:
            time.sleep(1)
    if not ready:
        raise RuntimeError('container_not_ready')
    test_env = dict(os.environ, PUSH_KIDS_DATABASE_URL=url, PUSH_KIDS_TEST_MYSQL_URL=url)
    migration = run([str(ROOT/'.venv/bin/python'), '-m', 'alembic', 'upgrade', 'head'], env=test_env, cwd=ROOT)
    status['migration_exit'] = migration.returncode
    (SAFE/'mysql57-migration.txt').write_text(migration.stdout.replace(password, '[REDACTED]'))
    if migration.returncode:
        raise RuntimeError('migration_failed')
    print('MySQL5.7 ready; running isolated legacy-compatibility and checkpoint/transaction gates', flush=True)
    result = run([str(ROOT/'.venv/bin/python'), '-m', 'pytest', 'tests/integration/test_system_one_mysql.py', 'tests/integration/test_staged_mysql.py', '-q'], env=test_env, cwd=ROOT)
    (SAFE/'mysql57-gate.txt').write_text(result.stdout.replace(password, '[REDACTED]'))
    status['pytest_exit'] = result.returncode
    print('\n'.join(result.stdout.splitlines()[-8:]).replace(password, '[REDACTED]'), flush=True)
except Exception as exc:
    status['error_class'] = type(exc).__name__
    print('MySQL gate incomplete: ' + type(exc).__name__, flush=True)
finally:
    removed = run(['docker', 'rm', '-f', '-v', name])
    status['container_removed'] = removed.returncode == 0
    (SAFE/'mysql57-summary.json').write_text(json.dumps(status, indent=2))
    print(json.dumps(status), flush=True)
