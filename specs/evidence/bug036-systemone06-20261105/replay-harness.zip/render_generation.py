"""Output-only review artifact. Never render source text, direct evidence or images."""
from collections import Counter
from html import escape
import hashlib
import json
from pathlib import Path
import statistics

PRIVATE = Path('/private/tmp/push-kids-systemone06-20261105')
RUN = PRIVATE / 'paired03'
OUT = Path('/Users/bytedance/.codex/visualizations/2026/11/05/01a1a9e5-f205-7ed2-98c2-4537082f530b/system-one-new-version')
EVIDENCE = Path('/Users/bytedance/Documents/push_kids/specs/evidence/bug036-systemone06-20261105')
rows = json.loads((RUN/'metrics.private.json').read_text())['results']
assert len(rows)==90 and all(sum(r['path']==p for r in rows)==45 for p in ['on','off'])
OUT.mkdir(exist_ok=True,parents=True)
EVIDENCE.mkdir(exist_ok=True,parents=True)


def percentile(values, q):
    values=sorted(values)
    position=(len(values)-1)*q
    lower=int(position)
    return round(values[lower]+(values[min(lower+1,len(values)-1)]-values[lower])*(position-lower),3)


def metrics(path):
    subset=[r for r in rows if r['path']==path]
    successes=[r for r in subset if r['success']]
    return {'n':len(subset),'first_success':sum(r['first_success'] for r in subset),'final_success':len(successes),'final_rate':round(len(successes)/len(subset)*100,3),'attempts':sum(len(r['attempts']) for r in subset),'seconds_p50':percentile([r['seconds'] for r in subset],.5),'seconds_p95':percentile([r['seconds'] for r in subset],.95),'success_seconds_p50':percentile([r['seconds'] for r in successes],.5),'success_seconds_p95':percentile([r['seconds'] for r in successes],.95),'acceptance_outcomes':dict(Counter(r['acceptance_outcome'] for r in successes)), 'acceptance_ms_p50':percentile([r['acceptance_ms'] for r in successes],.5),'acceptance_ms_p95':percentile([r['acceptance_ms'] for r in successes],.95),'valid_generation_attempts':sum(a['generation_succeeded'] for r in subset for a in r['attempts']), 'valid_generations_lost_after_acceptance':sum(a['generation_succeeded'] and not a['success'] for r in subset for a in r['attempts']), 'facts_preserved':sum(r['facts_preserved'] is True for r in successes), 'failed_cases':[{'case':r['case'],'round':r['round'],'reason':r['attempts'][-1].get('reason'),'stage':r['attempts'][-1].get('stage'),'unit':r['attempts'][-1].get('unit'),'attempts':len(r['attempts'])} for r in subset if not r['success']]}


summary={'on':metrics('on'),'off':metrics('off'),'business_writes':0,'human_quality_review':'PENDING','material_count':15,'rounds':3,'unavailable_materials':3,'candidate_manifest_sha256':hashlib.sha256((PRIVATE/'candidate02/source-manifest.json').read_bytes()).hexdigest(),'small_sample_limitation':'15 repeatedly sampled materials, not 45 independent inputs; no online or statistical noninferiority claim.'}
assert summary['on']['valid_generations_lost_after_acceptance']==0
(EVIDENCE/'generation-metrics.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
safe=[{k:v for k,v in r.items() if k not in {'proposal'}} for r in rows]
(EVIDENCE/'generation-rows.json').write_text(json.dumps(safe,ensure_ascii=False,indent=2))
labels={'no_finding':'未报疑点，待家长确认','needs_review':'建议家长核对','unavailable':'验收未完成，保留产物','skipped':'跳过验收，保留产物','disabled':'同期对照：未启用验收'}
reason_names={'validation':'原生成结果未通过校验','quality':'原生成复审未通过','coverage':'原生成完整性检查未通过','review':'原生成复审未通过','provider_timeout':'原生成调用超时','local_deadline':'原生成超出本次时间预算','queue_deadline':'原生成排队超时','rate_limited':'原生成服务限流','network':'原生成网络错误','provider_error':'原生成服务异常','incomplete':'原生成返回不完整'}
html_rows=[]
md_rows=[]
for r in sorted(rows,key=lambda r:(r['path']!='on',r['case'],r['round'])):
    raw=json.loads((RUN/f"{r['path']}-r{r['round']}-{r['case']}.private.json").read_text())
    p=raw['proposal']
    ident=f"{r['case']} · 第{r['round']}轮"
    if p:
        items=[]
        names=[]
        for i,point in enumerate(p['knowledge_points'],1):
            subject=point.get('subject_name') or p['subject_name']
            names.append(f"{subject}：{point['name']}（{point['review_method']}，{point['estimated_minutes']}分钟）")
            items.append(f"<div class='item'><span class='subject'>{escape(subject)}</span><strong>{i}. {escape(point['name'])}</strong><div class='method'>{escape(point['review_method'])} · {point['estimated_minutes']}分钟</div></div>")
        for match in p['todo_matches']:
            name=f"复习已有内容：{match['knowledge_name']}"
            items.append(f"<div class='item'><strong>{escape(name)}</strong></div>")
            names.append(name)
        hints=list(dict.fromkeys(p['uncertainties']))
        status=labels[r['acceptance_outcome']]
        advice=''.join(f'<li>{escape(h)}</li>' for h in hints)
        content=f"<p class='generated-summary'>摘要：{escape(p['summary'])}</p>"+''.join(items)
        note=f"<span class='badge'>{escape(status)}</span>"+(f'<ul>{advice}</ul>' if advice else '')
        names_md='摘要：'+escape(p['summary']).replace('|','&#124;')+'<br>'+'<br>'.join(escape(n).replace('|','&#124;') for n in names)
        note_md=escape(status)+('<br>'+'<br>'.join(escape(h).replace('|','&#124;') for h in hints) if hints else '')
    else:
        a=r['attempts'][-1]
        failure=reason_names.get(a.get('reason'),'原生成未形成可确认产物')
        names_md=content='未产出'
        note_md=escape(failure)
        note=f"<span class='badge failed'>未产出</span><p>{escape(failure)}；{len(r['attempts'])}次尝试</p>"
    html_rows.append(f"<tr data-path='{r['path']}'><td class='case'>{escape(ident)}</td><td>{content}</td><td>{note}</td><td class='time'>{r['seconds']:.2f}秒<br><small>{len(r['attempts'])}次尝试</small></td></tr>")
    if r['path']=='on':
        md_rows.append(f"| {ident} | {names_md} | {note_md} | {r['seconds']:.2f}秒 |")

on,off=summary['on'],summary['off']
header=f"<div class='metrics'><div><small>新版本最终产出</small><b>{on['final_success']}/45 · {on['final_rate']:.1f}%</b></div><div><small>同期关闭验收对照</small><b>{off['final_success']}/45 · {off['final_rate']:.1f}%</b></div><div><small>验收导致有效产物丢失</small><b>{on['valid_generations_lost_after_acceptance']} 份</b></div><div><small>新版本首轮产出</small><b>{on['first_success']}/45 · {on['first_success']/45*100:.1f}%</b></div></div>"
doc='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>新版本生成结果 · 家长 Review</title><style>
:root{color-scheme:light;font-family:system-ui,-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;color:#20352c;background:#f4f6f3}*{box-sizing:border-box}body{margin:0;padding:32px 24px}main{max-width:1440px;margin:auto}h1{font-size:28px;margin:0 0 10px}.intro{line-height:1.8;color:#52645a}.metrics{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:22px 0}.metrics>div{background:#fff;border:1px solid #dce5dd;border-radius:12px;padding:20px}.metrics small{display:block;color:#617369;margin-bottom:9px}.metrics b{font-size:25px}nav{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:25px 0 15px}button,input{font:inherit;border:1px solid #cad7cc;background:white;border-radius:8px;padding:11px 15px;min-height:44px}button{cursor:pointer}button[aria-pressed=true]{background:#285a40;color:#fff}input{min-width:260px;flex:1}.scroll{overflow:auto;border-radius:12px;border:1px solid #dbe4dd;background:white}table{border-collapse:collapse;width:100%;min-width:850px}th{background:#eaf0e9;text-align:left;font-size:14px;padding:16px;position:sticky;top:0}td{border-top:1px solid #e6ece6;padding:20px 16px;vertical-align:top;line-height:1.7}.case{width:125px;white-space:nowrap;color:#597065;font-size:14px}.time{width:115px;white-space:nowrap;font-size:14px}.time small{color:#738279}.item{margin-bottom:18px}.item:last-child{margin:0}.subject{font-size:12px;padding:3px 6px;border-radius:4px;background:#edf2eb;margin-right:8px}.method{font-size:14px;color:#617268;margin-top:4px}.badge{font-size:13px;background:#edf2e7;color:#375a25;padding:5px 8px;border-radius:5px;display:inline-block}.failed{background:#f7e9e4;color:#8b4131}ul{font-size:14px;margin:14px 0 0;padding-left:19px;max-width:410px}li{margin-bottom:9px}footer{font-size:13px;line-height:1.8;color:#64756a;margin-top:22px}tr[hidden]{display:none}@media(max-width:800px){body{padding:20px 12px}.metrics{grid-template-columns:repeat(2,1fr)}.metrics b{font-size:21px}h1{font-size:24px}}
</style><main><h1>新版本生成结果</h1><p class="intro">原 Pro 生成后，由 System One 辅助验收；所有结果仍需家长编辑、确认。表中只展示生成条目和核对意见，无原始输入或图片。</p>'''+header+f'''<p class="intro">15 份真实材料 × 3 轮；启闭验收共 90 次。新版本总耗时 p50 {on['seconds_p50']:.2f}秒 / p95 {on['seconds_p95']:.2f}秒；验收自身 p50 {on['acceptance_ms_p50']/1000:.2f}秒 / p95 {on['acceptance_ms_p95']/1000:.2f}秒。</p>'''+'''<nav aria-label="结果筛选"><button aria-pressed="true" data-filter="on">新版本 · 45次</button><button aria-pressed="false" data-filter="off">同期对照 · 45次</button><input type="search" aria-label="搜索生成结果" placeholder="搜索科目、条目或核对意见"></nav><div class="scroll"><table><thead><tr><th>样例 / 轮次</th><th>生成条目 / 复习方法</th><th>验收与核对意见</th><th>总耗时</th></tr></thead><tbody>'''+''.join(html_rows)+'''</tbody></table></div><footer>“未报疑点”只表示模型没有提出问题，不代表内容已经合格。内容质量待家长 Review。三轮重复15份材料，不能视为45份独立样本或线上成功率；另外3份原图失效的已取消提交不在可执行分母内。历史 Todo 与重复材料上下文无法完整重建，真实 Worker 状态/确认保护另由集成测试验证。本轮只读回放，未部署、未写真实学习数据。</footer></main><script>
let selected='on';const search=document.querySelector('input');function update(){const q=search.value.toLowerCase();document.querySelectorAll('tbody tr').forEach(r=>r.hidden=r.dataset.path!==selected||!r.textContent.toLowerCase().includes(q));}document.querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>{selected=b.dataset.filter;document.querySelectorAll('button').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));update();}));search.addEventListener('input',update);update();</script></html>'''
doc=doc.replace('本轮只读回放，未部署、未写真实学习数据。', '耗时从本地回放开始计，含本进程排队和实际重试，不含生产任务排队或重试等待间隔。本轮只读回放，未部署、未写真实学习数据。')
if (PRIVATE/'acceptance03/summary.json').exists():
    doc=doc.replace('</footer>', ' 检查器回归中，3份已知命名错误的指定来源问题均未检出；12份合成对照二分类正确11份、误报1份。因此验收意见只作辅助，内容仍需逐项人工确认。</footer>')
(OUT/'新版本生成结果表.html').write_text(doc)
md=f"# 新版本生成结果表\n\n最终产出 **{on['final_success']}/45，{on['final_rate']:.1f}%**；同期关闭验收对照 **{off['final_success']}/45，{off['final_rate']:.1f}%**。验收导致有效产物丢失 **0份**。\n\n15份真实材料×3轮，质量待家长Review；没有原始输入或图片。\n\n| 样例 / 轮次 | 生成条目 / 复习方法 | 验收与核对意见 | 总耗时 |\n|---|---|---|---|\n"+'\n'.join(md_rows)+'\n'
(OUT/'新版本生成结果表.md').write_text(md)
print(json.dumps(summary,ensure_ascii=False,indent=2))
print(OUT/'新版本生成结果表.html')
