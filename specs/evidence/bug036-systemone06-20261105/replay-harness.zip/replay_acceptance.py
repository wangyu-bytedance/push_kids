"""Actual frozen advisory checker against unchanged old output/label fixtures, no DB or Pro."""
import ast
import asyncio
import collections
import hashlib
import json
import logging
import os
from pathlib import Path
import random
import sys
from time import monotonic

os.umask(0o077)
logging.disable(logging.CRITICAL)
ROOT = Path('/Users/bytedance/Documents/push_kids')
OLD = Path('/private/tmp/push-kids-systemone05-20261105')
PRIVATE = Path('/private/tmp/push-kids-systemone06-20261105')
FROZEN = PRIVATE / 'candidate02'
RUN = PRIVATE / 'acceptance03'
sys.path.insert(0, str(FROZEN / 'apps/api/src'))
from push_kids.agent_processing.contracts import AnalysisInput, AnalysisProposal
from push_kids.agent_processing.proposal_acceptance import accept_proposal
from push_kids.agent_processing.system_one_provider import SystemOneDecisionProvider
from push_kids.agent_processing.telemetry import AnalysisTrace
from push_kids.platform.config import Settings


def jobs():
    samples = {s['alias']: s for s in json.loads(Path('/private/tmp/push-kids-success04-20261105/samples.private.json').read_text())['samples']}
    rows = []
    metrics = json.loads((OLD/'paired03-metrics.json').read_text())['results']
    for r in metrics:
        if r['path'] == 'old' and r['success']:
            p = json.loads((OLD/f"old03-r{r['round']}-{r['case']}.private.json").read_text())['proposal']
            rows.append({'id':f"b-r{r['round']}-{r['case']}", 'group':'baseline', 'sample':samples[r['case']], 'proposal':p})
    for round, case, keys in [(1,'real10',['i1_source','summary']), (1,'real18',['i0_source','summary']), (2,'real18',['i0_source','summary'])]:
        p = json.loads((OLD/f'new03-r{round}-{case}.private.json').read_text())['proposal']
        rows.append({'id':f'k-r{round}-{case}', 'group':'known_bad', 'sample':samples[case], 'proposal':p, 'expected_pass':False, 'expected_fail_keys':keys})
    # Read only the three fixture functions; old runtime imports and deleted workflow are never executed.
    fixture = ast.parse((OLD/'acceptance_only.py').read_text())
    selected = [n for n in fixture.body if isinstance(n, ast.FunctionDef) and n.name in {'point','proposal','synthetic_jobs'}]
    namespace = {}
    exec(compile(ast.Module(body=selected, type_ignores=[]), 'unchanged-synthetic-fixture', 'exec'), namespace)
    rows += namespace['synthetic_jobs']()
    assert len(rows)==58 and sum(r['group']=='baseline' for r in rows)==43
    random.Random(20261105).shuffle(rows)
    return rows


async def one(job, settings, slots):
    async with slots:
        sample = job['sample']
        public = dict(job['proposal'])
        # Old synthetic fixtures omitted the public root subject; each item already has its own.
        public.setdefault('subject_name', public['knowledge_points'][0].get('subject_name') or '语文')
        proposal = AnalysisProposal.model_validate(public)
        data = AnalysisInput(text=sample.get('input_text'), grade=sample.get('grade'), image_paths=[Path(m['destination']) for m in sample['media']], analysis_subjects=['数学','英语','语文'])
        before = proposal.model_dump(exclude={'uncertainties'})
        start = monotonic()
        output, audit = await accept_proposal(data, proposal, SystemOneDecisionProvider(settings), start+5, AnalysisTrace.disabled())
        preserved = before == output.model_dump(exclude={'uncertainties'})
        assert preserved
        keys = [f"coverage_{f.target}" if f.criterion=='coverage' else 'summary' if f.criterion=='summary' else 'separate' if f.criterion=='separate' else f'{f.target}_{f.criterion}' for f in audit.findings]
        row = {'id':job['id'], 'group':job['group'], 'outcome':audit.outcome, 'reason':audit.reason, 'seconds':round(monotonic()-start,3), 'facts_preserved':preserved, 'finding_keys':keys, 'expected_pass':job.get('expected_pass'), 'expected_fail_keys':job.get('expected_fail_keys')}
        if 'expected_pass' in job:
            row['binary_correct'] = (audit.outcome=='no_finding')==job['expected_pass'] if audit.outcome in {'no_finding','needs_review'} else False
            row['label_correct'] = audit.outcome=='no_finding' if job['expected_pass'] else audit.outcome=='needs_review' and bool(set(keys)&set(job['expected_fail_keys']))
        (RUN/(job['id']+'.private.json')).write_text(json.dumps({'result':row,'output':output.model_dump(mode='json'),'audit':audit.model_dump(mode='json')},ensure_ascii=False,indent=2))
        print(json.dumps(row,ensure_ascii=False),flush=True)
        return row


async def main():
    RUN.mkdir(mode=0o700,exist_ok=False)
    cases = jobs()
    manifest = {'source_manifest_sha256':hashlib.sha256((FROZEN/'source-manifest.json').read_bytes()).hexdigest(), 'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'labels_unchanged':True, 'cases':{j['id']:{'proposal_sha256':hashlib.sha256(json.dumps(j['proposal'],sort_keys=True,ensure_ascii=False).encode()).hexdigest(), 'text_sha256':hashlib.sha256((j['sample'].get('input_text') or '').encode()).hexdigest(), 'images_sha256':[hashlib.sha256(Path(m['destination']).read_bytes()).hexdigest() for m in j['sample']['media']], 'expected_pass':j.get('expected_pass'), 'expected_fail_keys':j.get('expected_fail_keys')} for j in cases}, 'business_writes':0,'pro_calls':0,'concurrency':2,'retries':0}
    (RUN/'manifest.private.json').write_text(json.dumps(manifest,indent=2))
    settings, slots = Settings(_env_file=ROOT/'.env'), asyncio.Semaphore(2)
    rows = await asyncio.gather(*(one(j,settings,slots) for j in cases))
    (RUN/'metrics.private.json').write_text(json.dumps(rows,indent=2))
    summary = {'n':len(rows),'groups':{g:{'n':sum(r['group']==g for r in rows),'outcomes':dict(collections.Counter(r['outcome'] for r in rows if r['group']==g)), 'facts_preserved':sum(r['facts_preserved'] for r in rows if r['group']==g), 'binary_correct':sum(bool(r.get('binary_correct')) for r in rows if r['group']==g), 'label_correct':sum(bool(r.get('label_correct')) for r in rows if r['group']==g)} for g in ['baseline','known_bad','synthetic']},'business_writes':0,'pro_calls':0,'human_review':'PENDING'}
    (RUN/'summary.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary),flush=True)

if __name__=='__main__': asyncio.run(main())
