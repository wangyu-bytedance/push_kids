"""Frozen same-source generation comparison; actual advisory implementation, no DB writes."""
import asyncio
import builtins
import copy
import hashlib
import json
import logging
import os
import sys
from pathlib import Path
from time import monotonic

os.umask(0o077)
logging.disable(logging.CRITICAL)
ROOT = Path('/Users/bytedance/Documents/push_kids')
PRIVATE = Path('/private/tmp/push-kids-systemone06-20261105')
FROZEN = PRIVATE / 'candidate02'
sys.path.insert(0, str(FROZEN / 'apps/api/src'))
sys.path.insert(0, str(ROOT / 'dist/knowledge-generation-evaluation-20261031-prompt04/harness'))
from run_generation import ranked_history
from push_kids.agent_processing.contracts import AnalysisInput, AnalysisOutputValidationError, ExistingKnowledgeContext, analysis_failure_disposition
from push_kids.knowledge.normalization import normalize_knowledge_name
from push_kids.agent_processing.pipeline import StagedPipeline
from push_kids.agent_processing.proposal_acceptance import accept_proposal
from push_kids.agent_processing.stage_provider import StagedArkProvider
from push_kids.platform.config import Settings


class Trace:
    def __init__(self): self.events = []
    def info(self, event, **fields):
        self.events.append({'event': event, **{k:v for k,v in fields.items() if k in {'stage','unit','duration_ms','queue_ms','input_tokens','output_tokens','request_bytes','reason','checkpoint_hit','revision','status','result_count'}}})
    warning = info


class MemoryStages:
    def __init__(self): self.rows = {}
    def get(self, unit, digest):
        entry = self.rows.get(unit)
        return copy.deepcopy(entry[1]) if entry and entry[0] == digest else None
    def put(self, unit, digest, value, *, deadline=None):
        size = len(json.dumps(value, ensure_ascii=False).encode())
        if size > 65535 or unit not in self.rows and len(self.rows) >= 18: raise RuntimeError('cache_capacity')
        if sum(len(json.dumps(v[1], ensure_ascii=False).encode()) for k,v in self.rows.items() if k != unit) + size > 512*1024: raise RuntimeError('cache_capacity')
        self.rows[unit] = digest, copy.deepcopy(value)


def history_row(h):
    return ExistingKnowledgeContext(knowledge_id=h['knowledge_id'], subject_name=h['subject_name'], name=h['name'], category=h['category'], review_method=h['review_method'], evidence=(h['evidence_json'] or '')[:4000], coverage_evidence_complete=len(h['evidence_json'] or '') <= 4000, review_status=h['review_status'], created_at=h['created_at'])


async def one(case, enabled, history, round):
    tag = ('on' if enabled else 'off') + f'-r{round}-' + case['alias']
    destination = PRIVATE / 'paired03' / (tag + '.private.json')
    if destination.exists(): raise RuntimeError('immutable result exists')
    provider = StagedArkProvider(Settings(_env_file=ROOT/'.env', PUSH_KIDS_SYSTEM_ONE_ENABLED=enabled))
    trace, cache, attempts, proposal, acceptance = Trace(), MemoryStages(), [], None, None
    started = monotonic()
    for attempt in range(1, 4):
        data = AnalysisInput(text=case['input_text'], image_paths=[Path(m['destination']) for m in case['media']], grade=case.get('grade'), occurred_at=case.get('occurred_at'), analysis_subjects=['语文','数学','英语'])
        supplement, searched = set(), set()
        tool_calls = 0
        def search(request):
            nonlocal tool_calls
            if tool_calls >= 20: raise AnalysisOutputValidationError(['history_search.tool_budget'])
            tool_calls += 1
            candidate = normalize_knowledge_name(request.candidate_key)
            if not candidate: raise AnalysisOutputValidationError(['history_search.candidate_key'])
            rows = ranked_history(history['history'], case, request)
            supplement.update(h['knowledge_id'] for h in rows)
            if len(supplement) > 100: raise AnalysisOutputValidationError(['history_search.result_budget'])
            searched.add((request.subject_name, candidate))
            known = {h.knowledge_id for h in data.existing_knowledge}
            data.existing_knowledge.extend(history_row(h) for h in rows if h['knowledge_id'] not in known)
            return [history_row(h).model_dump() for h in rows]
        before = monotonic()
        phase = 'generation'
        attempt_state = {'attempt':attempt, 'generation_succeeded':False, 'acceptance_started':False, 'acceptance_returned':False, 'facts_preserved':None}
        try:
            async with asyncio.timeout(270):
                output = await StagedPipeline(provider, trace, cache).run(data, search, before + 270)
            output = data.validate_proposal(output)
            if any((p.subject_name or output.subject_name, normalize_knowledge_name(p.name)) not in searched for p in output.knowledge_points):
                raise AnalysisOutputValidationError(['history_search.incomplete'])
            attempt_state['generation_succeeded'] = True
            generation_seconds = monotonic() - before
            # Match the existing Worker grade/history hint; no historical Todo/duplicate snapshot is invented.
            if not data.grade or not data.recent_learning:
                output.uncertainties = (output.uncertainties + ['年级或已确认历史不完整，请核对知识点粒度；未推断学习阶段。'])[-20:]
            facts_before = output.model_dump(exclude={'uncertainties'})
            phase = 'acceptance'
            attempt_state['acceptance_started'] = True
            output, audit = await accept_proposal(data, output, provider.acceptance_provider, before + 270, trace)
            attempt_state['acceptance_returned'] = True
            attempt_state['facts_preserved'] = output.model_dump(exclude={'uncertainties'}) == facts_before
            assert output.model_dump(exclude={'uncertainties'}) == facts_before, 'acceptance_changed_facts'
            phase = 'post_validation'
            data.validate_proposal(output)
            proposal, acceptance = output.model_dump(mode='json'), audit.model_dump(mode='json')
            attempts.append({**attempt_state,'success':True,'generation_seconds':builtins.round(generation_seconds,3),'seconds':builtins.round(monotonic()-before,3)})
            break
        except Exception as exc:
            disposition = analysis_failure_disposition(exc)
            attempts.append({**attempt_state,'success':False,'failure_phase':phase,'seconds':builtins.round(monotonic()-before,3),'reason':disposition.reason,'code':disposition.code,'retryable':disposition.retryable,'stage':getattr(exc,'stage',''),'unit':getattr(exc,'unit',''),'error_type':type(exc).__name__})
            if not disposition.retryable: break
    result = {'case':case['alias'],'path':'on' if enabled else 'off','round':round,'success':proposal is not None,'first_success':attempts[0]['success'],'seconds':builtins.round(monotonic()-started,3),'attempts':attempts,'acceptance_outcome':acceptance['outcome'] if acceptance else None,'acceptance_ms':acceptance['duration_ms'] if acceptance else None,'finding_count':len(acceptance['findings']) if acceptance else None,'facts_preserved':True if proposal else None,'calls':sum(e['event']=='analysis_stage_completed' for e in trace.events)}
    destination.write_text(json.dumps({'result':result,'proposal':proposal,'acceptance':acceptance,'trace':trace.events},ensure_ascii=False,indent=2))
    print(json.dumps(result,ensure_ascii=False),flush=True)
    return result


async def main():
    run = PRIVATE / 'paired03'
    run.mkdir(exist_ok=False)
    samples = json.loads(Path('/private/tmp/push-kids-success04-20261105/samples.private.json').read_text())['samples']
    history = json.loads(Path('/private/tmp/push-kids-success04-20261105/history.private.json').read_text())
    cases = [s for s in samples if s['available']]
    assert len(cases) == 15
    source = {str(p.relative_to(FROZEN)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (FROZEN/'apps/api/src').rglob('*.py')}
    manifest = {'spec_revision':'BUG-SPEC-20261105-SYSTEM-ONE-06','source_sha256':source,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'input_sha256':{s['alias']:{'text_sha256':hashlib.sha256((s['input_text'] or '').encode()).hexdigest(),'images':[hashlib.sha256(Path(m['destination']).read_bytes()).hexdigest() for m in s['media']]} for s in cases},'rounds':3,'max_attempts':3,'processes':1,'global_request_slots':2,'concurrent_paths':2,'business_writes':0,'history_limitation':'As-of filtered, current unversioned evidence; historical Todo and duplicate-material snapshots unavailable; live Worker wiring verified separately.'}
    (run/'manifest.private.json').write_text(json.dumps(manifest,indent=2))
    results = []
    for round in range(1,4):
        ordered = cases[(round-1)*5:] + cases[:(round-1)*5]
        for index, case in enumerate(ordered):
            paths = [True,False] if (index+round)%2 else [False,True]
            pair = await asyncio.gather(*(one(case, flag, history, round) for flag in paths))
            results.extend(pair)
            (run/'metrics.private.json').write_text(json.dumps({'results':results,'unavailable':[s['alias'] for s in samples if not s['available']],'business_writes':0},ensure_ascii=False,indent=2))
    assert len(results) == 90
    print('COMPLETED 90',flush=True)


if __name__ == '__main__': asyncio.run(main())
