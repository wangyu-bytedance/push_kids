BUG-037 screenshot recovery 02

96 original official WeChat DevTools PNGs with matching native-node JSON:
embedded/standalone x 390/430 x 24 states.
All native geometry checks and PNG hashes passed.

These images use synthetic read-only data in a real native Mini Program simulator.
They are NOT physical-device acceptance.
320 viewport NOT_RUN. iOS/Android hardware NOT_RUN. Large font/screen reader NOT_RUN.

The separate official device preview QR uses 168 frozen production client files
with only the 2 approved BUG-037 files replaced; no synthetic API is packaged.
Preview success: 1,192,127 bytes. No upload/experience/review/production action.
Unlock the Mac, then scan the QR with the project developer's WeChat to continue.
