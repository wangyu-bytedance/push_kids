BUG-037: 144 native simulator screenshots + native-node JSON.
Two hosts x 3 actual simulator viewports (320x568, 390x844, 430x932) x 24 states.
Geometry, image decoding and SHA-256 verified. Synthetic read-only data, actual production WXML/WXSS.
Physical-device screenshots, large font, screen reader and actual touch are NOT_RUN.
Official production preview succeeded (1,192,127 bytes). No upload/release.
Scan the separate official remote-debug QR with project developer WeChat to continue device acceptance.
